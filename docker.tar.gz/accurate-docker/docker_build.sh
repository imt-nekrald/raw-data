#!/usr/bin/env bash

sudo docker build -t nekraldimt/accurate-price-and-schedule .
