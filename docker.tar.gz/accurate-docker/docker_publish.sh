#!/usr/bin/env bash

# sudo docker login
sudo docker push nekraldimt/accurate-price-and-schedule
