#!/usr/bin/env python3

from typing import Any
from typing import TextIO

import subprocess
import logging
import json
import os
import shutil


class Constants:
    DATA_INPUTS: str = '/data/inputs/'
    DATA_OUTPUTS: str = '/data/outputs/'

    CUSTOM_DATA_FILE: str = 'algoCustomData.json'
    CUSTOM_DATA_PATH: str = os.path.join('/data/inputs/', CUSTOM_DATA_FILE)

    CONFIGURATION_JSON: str = 'configuration.json'
    PARAMETERS_JSON: str = 'parameters.json'
    REQUEST_JSON: str = 'request.json'
    OUTPUT_JSON: str = 'output.json'

    REQUEST_KEY: str = 'request'
    CONFIGURATION_KEY: str = 'configuration'
    PARAMETERS_KEY: str = 'parameters'

    ONBOARD_BINARY: str = 'onboard'

    MAIN_PYTHON_LOG: str = 'python-main.log'
    DEBUG_PYTHON_LOG: str = 'python-debug.log'


def setup_logging(main_log_address: str,
                  debug_log_address: str,
                  console_debug: bool) -> None:
    """ Sets up logging configuration.

    Args:
        main_log_address: Address of the main log file (INFO level).
        debug_log_address: Address of the debug log file (DEBUG level).
        console_debug: Indicator about setting console logging to DEBUG level.
    """
    os.makedirs(os.path.dirname(main_log_address), exist_ok=True)
    os.makedirs(os.path.dirname(debug_log_address), exist_ok=True)

    handler: logging.Handler
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)

    logger: logging.Logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    debug_file_handler: logging.FileHandler = logging.FileHandler(debug_log_address)
    debug_file_handler.setLevel(logging.DEBUG)

    info_file_handler: logging.FileHandler = logging.FileHandler(main_log_address)
    info_file_handler.setLevel(logging.INFO)

    console_handler: logging.StreamHandler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG if console_debug else logging.INFO)

    formatter: logging.Formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s')
    handlers: list[logging.Handler] = [debug_file_handler, info_file_handler, console_handler]

    handler_item: logging.Handler
    for handler_item in handlers:
        handler_item.setFormatter(formatter)
        logger.addHandler(handler_item)


def execute_algorithm() -> None:
    setup_logging(
        os.path.join(Constants.DATA_OUTPUTS, Constants.MAIN_PYTHON_LOG),
        os.path.join(Constants.DATA_OUTPUTS, Constants.DEBUG_PYTHON_LOG),
        console_debug=False
    )

    input_dir: str = Constants.DATA_INPUTS
    files: list[str] = [file_item for file_item in os.listdir(input_dir)
        if file_item != Constants.CUSTOM_DATA
        and os.path.isfile(os.path.join(input_dir, file_item))]
    request_json_path: str = os.path.join(input_dir, files[0])
    request_params: dict[str, Any]
    request_file: TextIO
    with open(request_json_path, 'r') as request_file:
        request_params = json.load(request_file)

    custom_params_path: str = Constants.CUSTOM_DATA
    custom_params: dict[str, Any]
    params_file: TextIO
    with open(custom_params_path, 'r') as params_file:
        custom_params = json.load(params_file)
    call_cpp_submodule(request_params, custom_params)


def prepare_cpp_inputs(request_params: dict[str, Any],
                       custom_params: dict[str, Any]) -> None:
    cpp_configuration_dict: dict[str, Any] = request_params[Constants.CONFIGURATION_KEY]
    cpp_parameters_dict: dict[str, Any] = request_params[Constants.PARAMETERS_KEY]
    cpp_request_dict: dict[str, Any] = request_params[Constants.REQUEST_KEY]
    configuration_file: TextIO
    with open(Constants.CONFIGURATION_JSON, "w") as configuration_file:
        json.dump(cpp_configuration_dict, configuration_file, indent=4)
    parameters_file: TextIO
    with open(Constants.PARAMETERS_JSON, "w") as parameters_file:
        json.dump(cpp_parameters_dict, parameters_file, indent=4)
    request_file: TextIO
    with open(Constants.REQUEST_JSON, "w") as request_file:
        json.dump(cpp_request_dict, request_file, indent=4)
    logging.info("Prepared inputs for cpp binary.")


def call_cpp_submodule(request_params: dict[str, Any],
                       custom_params: dict[str, Any]) -> None:
    prepare_cpp_inputs(request_params, custom_params)
    if not os.path.isfile(Constants.ONBOARD_BINARY):
        logging.error("Onboard binary not found!")
    command: list[str] = [
        "./" + Constants.ONBOARD_BINARY,
        '--configuration-json-path', Constants.CONFIGURATION_JSON,
        '--parameters-json-path', Constants.PARAMETERS_JSON,
        '--request-json-path', Constants.REQUEST_JSON,
        '--output-json-path', os.path.join(Constants.DATA_OUTPUTS, Constants.OUTPUT_JSON),
        '--log-directory', os.path.join(Constants.DATA_OUTPUTS),
    ]
    process: subprocess.Popen = subprocess.Popen(command)
    return_code: int = process.wait()
    if return_code != 0:
        logging.error("Subprocess returned non-zero exit code.")
    logging.info("Existing caller for the cpp submodule.")
    shutil.move(
        Constants.CONFIGURATION_JSON,
        os.path.join(Constants.DATA_OUTPUTS, Constants.CONFIGURATION_JSON))
    shutil.move(
        Constants.PARAMETERS_JSON,
        os.path.join(Constants.DATA_OUTPUTS, Constants.PARAMETERS_JSON))
    shutil.move(
        Constants.REQUEST_JSON,
        os.path.join(Constants.DATA_OUTPUTS, Constants.REQUEST_JSON))


if __name__ == '__main__':
    file_path: str = os.path.abspath(__file__)
    os.chdir(os.path.dirname(file_path))
    execute_algorithm()

