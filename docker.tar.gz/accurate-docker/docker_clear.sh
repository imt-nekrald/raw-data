#!/usr/bin/env bash

sudo service docker restart
sudo docker builder prune --all
