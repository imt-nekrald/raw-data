#!/usr/bin/env bash

set -uexo 

sudo rm -rf data/outputs*
export DIDS="[ \"0d9e8ecff0904cdbb3a770ea72ffb878948cca15675b4d92a326619f1f08327f\" ]"
directory=`pwd`
sudo docker run --env DIDS="$DIDS" --mount type=bind,src="$directory/data",dst=/data nekraldimt/accurate-price-and-schedule:latest
mv data/outputs data/outputs_1

export DIDS="[ \"cd20ddbdaf094beeaa363f2caaeff6e8c3143f58403e41039c50f380e514c8eb\" ]"
directory=`pwd`
sudo docker run --env DIDS="$DIDS" --mount type=bind,src="$directory/data",dst=/data nekraldimt/accurate-price-and-schedule:latest
mv data/outputs data/outputs_2

export DIDS="[ \"0e82bbf07d77468d9c402e8ce729139748849292aabc46a9aef7fe5e925caf8f\" ]"
directory=`pwd`
sudo docker run --env DIDS="$DIDS" --mount type=bind,src="$directory/data",dst=/data nekraldimt/accurate-price-and-schedule:latest
mv data/outputs data/outputs_3

set +uexo
