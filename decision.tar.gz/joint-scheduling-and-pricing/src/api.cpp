#include <iostream>
#include <fstream>
#include <memory>
#include <cstdlib>
#include <string>
#include <cctype>

#include <json/json.h>
#include <json/writer.h>
#include <boost/log/core.hpp>
#include <boost/log/expressions.hpp>
#include <boost/log/sinks/text_file_backend.hpp>
#include <boost/log/sources/record_ostream.hpp>
#include <boost/log/sources/severity_logger.hpp>
#include <boost/log/trivial.hpp>
#include <boost/log/utility/setup/common_attributes.hpp>
#include <boost/log/utility/setup/console.hpp>
#include <boost/log/utility/setup/file.hpp>

#include "api.h"
#include "data/setting.h"
#include "data/sampler.h"
#include "policy/price_interface.h"
#include "policy/static_price.h"
#include "policy/rollout_price.h"
#include "schedule/scheduler_interface.h"
#include "schedule/scheduling_state.h"
#include "schedule/fifo_scheduler.h"
#include "evaluate/scorer.h"
#include "search/genetic.h"
#include "estimation/gurobi_estimator.h" // IWYU pragma: keep
#include "estimation/hexaly_estimator.h" // IWYU pragma: keep
#include "evaluate/trajectory_manager.h"
#include "evaluate/confidence.h"

namespace logging = boost::log;
namespace sinks = boost::log::sinks;
namespace keywords = boost::log::keywords;


void InitializeLogging(const std::string& log_folder) {
    logging::add_common_attributes();
    logging::register_simple_formatter_factory<
    boost::log::trivial::severity_level, char>("Severity");
    logging::add_file_log(
            keywords::target = log_folder,
            keywords::file_name = "log_cpp_%y%m%d_%3N.log",
            keywords::rotation_size = 10 * 1024 * 1024,
            keywords::scan_method = sinks::file::scan_matching,
            keywords::format="[%TimeStamp%][%Severity%]: %Message%");
    logging::add_console_log(std::cout,
            boost::log::keywords::format = ">> %Message%");
    logging::core::get()->set_filter(
            logging::trivial::severity >= logging::trivial::info);
}


namespace accurate {

EvaluationBasis PrepareEvaluationBasis(
        const Setting& setting,
        unsigned estimator_time_limit,
        unsigned evaluation_sample_count,
        unsigned rollout_sample_count,
        unsigned nested_sample_count) {
    EvaluationBasis basis;
    basis.setting = setting;
    basis.sampler = std::make_shared<Sampler>(basis.setting);
    basis.evaluation_sample_count = evaluation_sample_count;
    basis.rollout_sample_count = rollout_sample_count;
    basis.nested_sample_count = nested_sample_count;
    basis.trajectory_manager = std::make_shared<RandomTrajectoryManager>(
            basis.setting, evaluation_sample_count, basis.sampler, evaluation_sample_count);
    std::shared_ptr<IOnlineScheduler> scheduler = std::make_shared<OnlineFIFOScheduler>(
            basis.setting);
    basis.initial_state = scheduler->GetState();
    basis.estimator_time_limit = estimator_time_limit;
    return basis;
}

#ifdef RESEARCH_MODE
ConfidenceResult ProcessGurobiEstimation(
        const EvaluationBasis& basis, bool continuous_relaxation) {
    bool continuous_prices = false;
    std::shared_ptr<IPerfectInfoEstimator> gurobi_estimator = std::make_shared<
        GurobiPerfectInfoEstimator>(basis.setting, continuous_prices,
                continuous_relaxation, basis.estimator_time_limit);
    std::shared_ptr<IStateScorer> gurobi_scorer = std::make_shared<
        SolverScorer>(basis.setting, basis.trajectory_manager, gurobi_estimator);
    ConfidenceResult gurobi_score = gurobi_scorer->GetScore(basis.initial_state);
    return gurobi_score;
}
#endif

#ifdef RESEARCH_MODE
ConfidenceResult ProcessHexalyEstimation(
        const EvaluationBasis& basis, bool continuous_relaxation) {
    bool continuous_prices = false;
    std::shared_ptr<IPerfectInfoEstimator> hexaly_estimator = std::make_shared<
            HexalyPerfectInfoEstimator>(basis.setting, continuous_prices,
                    continuous_relaxation, basis.estimator_time_limit);
    std::shared_ptr<IStateScorer> hexaly_scorer = std::make_shared<
            SolverScorer>(basis.setting, basis.trajectory_manager, hexaly_estimator);
    ConfidenceResult hexaly_score = hexaly_scorer->GetScore(basis.initial_state);
    return hexaly_score;
}
#endif

StaticPriceList PerformGeneticSearch(
        const EvaluationBasis& basis, const GeneticConfig& config) {
    GeneticPriceSearch search(basis.setting, config);
    std::vector<StaticPriceList> initialization = {
        PriceToMinimal(basis.setting), PriceToMaximal(basis.setting) };

    unsigned n_generations = 5;
    for (unsigned sample_seed = 0; sample_seed < n_generations; ++sample_seed) {
        unsigned initialization_seed = sample_seed;
        initialization.push_back(
                PriceMinMaxRandomization(basis.setting, 0.95, initialization_seed));
        initialization_seed += n_generations;
        initialization.push_back(
                PriceMinMaxRandomization(basis.setting, 0.8, initialization_seed));
        initialization_seed += n_generations;
        initialization.push_back(
                PriceMinMaxRandomization(basis.setting, 0.5, initialization_seed));
        initialization_seed += n_generations;
        initialization.push_back(
                PriceMinMaxRandomization(basis.setting, 0.2, initialization_seed));
        initialization_seed += n_generations;
        initialization.push_back(
                PriceMinMaxRandomization(basis.setting, 0.05, initialization_seed));
}
    StaticPriceList genetic_price_list = search.PrepareStaticPrices(initialization);
    return genetic_price_list;
}

ConfidenceResult ComputeRevenueAtStaticPrice(
        const EvaluationBasis& basis,
        const StaticPriceList& price_list) {
    std::shared_ptr<IOnlineScheduler> scheduler = std::make_shared<
            OnlineFIFOScheduler>(basis.setting);
    std::shared_ptr<IPolicy> policy = std::make_shared<
            StaticPricePolicy>(price_list, basis.setting, scheduler);
    std::shared_ptr<IPolicyScorer> policy_scorer = std::make_shared<
            SamplingScorer>(basis.setting, basis.trajectory_manager);
    ConfidenceResult revenue = policy_scorer->GetScore(0, 0., policy);
    return revenue;
}

ConfidenceResult ComputeRevenueAtRolloutPrice(
        const EvaluationBasis& basis, const StaticPriceList& price_list) {
    std::shared_ptr<IOnlineScheduler> scheduler = std::make_shared<
            OnlineFIFOScheduler>(basis.setting);
    std::shared_ptr<IPolicy> static_policy = std::make_shared<
            StaticPricePolicy>(price_list, basis.setting, scheduler);
    std::shared_ptr<IPolicy> rollout_policy = std::make_shared<ExtendingRolloutPricePolicy>(
            static_policy, basis.setting, basis.rollout_sample_count);
    std::shared_ptr<IPolicyScorer> policy_scorer = std::make_shared<SamplingScorer>(
            basis.setting, basis.trajectory_manager);
    ConfidenceResult revenue = policy_scorer->GetScore(0, 0., rollout_policy);
    return revenue;
}

ConfidenceResult ComputeRevenueAtNestedPrice(
        const EvaluationBasis& basis,
        const StaticPriceList& price_list) {
    std::shared_ptr<IOnlineScheduler> scheduler = std::make_shared<
        OnlineFIFOScheduler>(basis.setting);
    std::shared_ptr<IPolicy> static_policy = std::make_shared<
        StaticPricePolicy>(price_list, basis.setting, scheduler);
    std::shared_ptr<IPolicy> rollout_policy = std::make_shared<ExtendingRolloutPricePolicy>(
        static_policy, basis.setting, basis.nested_sample_count);
    std::shared_ptr<IPolicy> nested_policy = std::make_shared<ExtendingRolloutPricePolicy>(
        rollout_policy, basis.setting, basis.nested_sample_count);

    std::shared_ptr<IPolicyScorer> policy_scorer = std::make_shared<
        SamplingScorer>(basis.setting, basis.trajectory_manager);

    ConfidenceResult revenue = policy_scorer->GetScore(0, 0., nested_policy);
    return revenue;
}


ConfidenceResult ComputeRevenueAtStaticMaximalPrice(const EvaluationBasis& basis) {
    return ComputeRevenueAtStaticPrice(basis, PriceToMaximal(basis.setting));
}

ConfidenceResult ComputeRevenueAtRolloutMaximalPrice(const EvaluationBasis& basis) {
    return ComputeRevenueAtRolloutPrice(basis, PriceToMaximal(basis.setting));
}

ConfidenceResult ComputeRevenueAtMinimalPrice(const EvaluationBasis& basis) {
    return ComputeRevenueAtStaticPrice(basis, PriceToMinimal(basis.setting));
}


ConfidenceResult ComputeGeneticStaticRevenue(
        const EvaluationBasis& basis, const StaticPriceList& genetic_price_list) {
    return ComputeRevenueAtStaticPrice(basis, genetic_price_list);
}

ConfidenceResult ComputeGeneticRolloutRevenue(
        const EvaluationBasis& basis, const StaticPriceList& genetic_price_list) {
    return ComputeRevenueAtRolloutPrice(basis, genetic_price_list);
}

ConfidenceResult ComputeGeneticNestedRevenue(
        const EvaluationBasis& basis, const StaticPriceList& genetic_price_list) {
    return ComputeRevenueAtNestedPrice(basis, genetic_price_list);
}

Json::Value ParseJsonFromFile(const std::string& path) {
    std::ifstream input_stream(path, std::ios::binary);
    if (!input_stream) {
        throw std::runtime_error("Cannot open file: " + path);
    }

    Json::CharReaderBuilder builder;
    builder["collectComments"] = false;

    Json::Value json_root;
    std::string errors;
    if (!Json::parseFromStream(builder, input_stream, &json_root, &errors)) {
        throw std::runtime_error("JSON parse error: " + errors);
    }
    return json_root;
}


void WriteJsonToFile(const Json::Value& value, const std::string& path) {
    std::ofstream result_io(path);
    result_io << value << std::endl;
    result_io.close();
}


} // namespace accurate

