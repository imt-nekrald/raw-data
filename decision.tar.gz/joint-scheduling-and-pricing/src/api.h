#pragma once

#include <memory>
#include <string>
#include <json/json.h>

#include "data/setting.h"
#include "data/sampler.h"
#include "policy/static_price.h"
#include "search/genetic.h"
#include "schedule/scheduling_state.h"
#include "evaluate/confidence.h"


void InitializeLogging(const std::string& log_dir_path);


namespace accurate {

struct EvaluationBasis {
    Setting setting;
    unsigned evaluation_sample_count;
    std::shared_ptr<Sampler> sampler;
    unsigned rollout_sample_count;
    unsigned nested_sample_count;
    std::shared_ptr<ITrajectoryManager> trajectory_manager;
    SchedulingState initial_state;
    unsigned estimator_time_limit;
    std::string instance_name;
};

EvaluationBasis PrepareEvaluationBasis(
    const Setting& setting,
    unsigned estimator_time_limit,
    unsigned evaluation_sample_count,
    unsigned rollout_sample_count,
    unsigned nested_sample_count);

#ifdef RESEARCH_MODE
ConfidenceResult ProcessGurobiEstimation(
    const EvaluationBasis& basis,
    bool continuous_relaxation);
#endif
#ifdef RESEARCH_MODE
ConfidenceResult ProcessHexalyEstimation(
    const EvaluationBasis& basis,
    bool continuous_relaxation);
#endif


ConfidenceResult ComputeRevenueAtStaticMaximalPrice(
    const EvaluationBasis& basis);
ConfidenceResult ComputeRevenueAtRolloutMaximalPrice(
    const EvaluationBasis& basis);
ConfidenceResult ComputeRevenueAtMinimalPrice(
    const EvaluationBasis& basis);
StaticPriceList PerformGeneticSearch(
    const EvaluationBasis& basis,
    const GeneticConfig& config);

ConfidenceResult ComputeRevenueAtStaticPrice(
    const EvaluationBasis& basis,
    const StaticPriceList& price_list);
ConfidenceResult ComputeRevenueAtRolloutPrice(
    const EvaluationBasis& basis,
    const StaticPriceList& price_list);
ConfidenceResult ComputeRevenueAtNestedPrice(
    const EvaluationBasis& basis,
    const StaticPriceList& price_list);

ConfidenceResult ComputeGeneticStaticRevenue(
    const EvaluationBasis& basis,
    const StaticPriceList& provided_list);
ConfidenceResult ComputeGeneticRolloutRevenue(
    const EvaluationBasis& basis,
    const StaticPriceList& provided_list);
ConfidenceResult ComputeGeneticNestedRevenue(
    const EvaluationBasis& basis,
    const StaticPriceList& provided_list);

Json::Value ParseJsonFromFile(
    const std::string& path);
void WriteJsonToFile(
    const Json::Value& value,
    const std::string& path);

} // namespace accurate

