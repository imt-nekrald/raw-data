#pragma once

#include <vector>
#include <map>
#include <set>
#include <tuple>

#include "../data/setting.h"
#include "../data/trajectory.h"
#include "../schedule/scheduling_state.h"
#include "../schedule/scheduling_task.h"
#include "../schedule/scheduler_interface.h"

namespace accurate {

struct SummaryInfo {
    std::vector<std::vector<SchedulingTask>> tasks;

    std::vector<SchedulingTask> index_to_task;
    std::map<std::string, SchedulingTask> uuid_to_task;
    std::map<std::string, unsigned> uuid_to_task_index;

    std::vector<double> price_per_task_group;
    std::vector<unsigned> period_ids;
    std::set<std::string> declined_tasks;
    std::set<std::string> allocated_tasks;
    std::map<std::string, Interval> uuid_to_allocation;
    unsigned n_preaccepted_groups = 0;
    unsigned n_groups = 0;
    unsigned n_tasks = 0;

    double upper_bound_start_time = 0.;
    double upper_bound_completion_time = 0.;
};


class IPerfectInfoEstimator {
public:
    IPerfectInfoEstimator(
            const Setting& setting,
            bool assume_continuous_prices,
            bool continuous_relaxation,
            unsigned time_limit)
            : kSetting(setting)
            , kContinuousPrices(assume_continuous_prices)
            , kContinuousRelaxation(continuous_relaxation)
            , kTimeLimit(time_limit) {};
    virtual std::tuple<double, double, double> EvaluateTrajectory(
            const SchedulingState& state, const Trajectory& trajectory) = 0;
    virtual SchedulingPlan SuggestSchedule(
            const SchedulingState& state, const Trajectory& trajectory) = 0;
    virtual ~IPerfectInfoEstimator() = default;

protected:
    virtual void ResetSummaryInfo();
    virtual void ProcessTrajectoryInfo(
            const Trajectory& trajectory, unsigned state_period);
    virtual void ProcessStateInfo(const SchedulingState& state);
    virtual void ComputeTimeMargins(
            const SchedulingState& state, const Trajectory& trajectory);

protected:
    const Setting kSetting;
    SummaryInfo summary_info_;
    const bool kContinuousPrices;
    const bool kContinuousRelaxation;
    const unsigned kTimeLimit;
};


} // namespace accurate
