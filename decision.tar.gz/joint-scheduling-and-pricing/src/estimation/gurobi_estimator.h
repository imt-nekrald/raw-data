#pragma once


#include <vector>
#include <memory>
#include <tuple>

#ifdef RESEARCH_MODE
#include <gurobi_c++.h>
#endif

#include "../estimation/estimator_interface.h"
#include "../data/setting.h"
#include "../schedule/scheduling_state.h"
#include "../schedule/scheduler_interface.h"


namespace accurate {

#ifdef RESEARCH_MODE
struct GurobiInfo {
    std::shared_ptr<GRBModel> model;
    std::vector<GRBVar> if_group_accepted;
    std::vector<GRBVar> task_start;
    std::vector<GRBVar> task_completion;
    std::vector<GRBVar> task_decline;
    std::vector<std::vector<GRBVar>> task_machine_assignment; // [machine_idx][task_idx]

    std::vector<std::vector<unsigned>> load_index;
    std::vector<GRBVar> load_precedence; // [task_idx][task_jdx]
    std::vector<GRBVar> due_difference;
};
#endif


#ifdef RESEARCH_MODE
class GurobiPerfectInfoEstimator : public IPerfectInfoEstimator {
public:
    GurobiPerfectInfoEstimator(
            const Setting& setting,
            bool assume_continuous_prices,
            bool continuous_relaxation,
            unsigned time_limit);
    virtual std::tuple<double,double,double> EvaluateTrajectory(
            const SchedulingState& state,
            const Trajectory& trajectory) override final;
    virtual SchedulingPlan SuggestSchedule(
            const SchedulingState& state,
            const Trajectory& trajectory) override final;
    virtual ~GurobiPerfectInfoEstimator() = default;

private:
    void ResetGurobiInfo();
    void FormGurobiVariables();
    void FormTrajectoryConstraints();
    void FormPrecedenceConstraints();
    void FormStateConstraints();
    void FormGurobiObjective();

private:
    GurobiInfo gurobi_info_;
};
#endif

} //namespace accurate

