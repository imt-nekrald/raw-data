#include <algorithm>
#include <stdexcept>
#include <string>
#include <cassert>
#include <tuple>

#ifdef RESEARCH_MODE
#include <optimizer/hexalyoptimizer.h>
#include <optimizer/hxexpression.h>
#endif

#include "../data/setting.h"
#include "../schedule/scheduling_state.h"
#include "../schedule/scheduling_task.h"
#include "../schedule/scheduler_interface.h"
#include "../estimation/estimator_interface.h"
#include "../estimation/hexaly_estimator.h"


namespace accurate {

#ifdef RESEARCH_MODE
static hexaly::HxExpression SumExpressions(
    const std::vector<hexaly::HxExpression>& components, hexaly::HxModel* model) {
    hexaly::HxExpression accumulated = model->createConstant(0.0);
    for (unsigned idx = 0; idx < components.size(); ++idx) {
        accumulated = accumulated + components[idx];
    }
    return accumulated;
}

HexalyPerfectInfoEstimator::HexalyPerfectInfoEstimator(
        const Setting& setting,
        bool assume_continuous_prices,
        bool continuous_relaxation,
        unsigned time_limit)
        : IPerfectInfoEstimator(
                setting,
                assume_continuous_prices,
                continuous_relaxation,
                time_limit) {
}

std::tuple<double, double, double> HexalyPerfectInfoEstimator::EvaluateTrajectory(
        const SchedulingState& state,
        const Trajectory& trajectory) {
    ResetSummaryInfo();
    ProcessStateInfo(state);
    ProcessTrajectoryInfo(trajectory, state.state_period);
    ComputeTimeMargins(state, trajectory);

    ResetHexalyInfo();
    hexaly::HxModel model = hexaly_info_.optimizer->getModel();

    FormHexalyVariables(&model);
    FormTrajectoryConstraints(&model);
    FormPrecedenceConstraints(&model);
    FormStateConstraints(&model);
    FormHexalyObjective(&model);

    model.close();
    hexaly_info_.optimizer->getParam().setTimeLimit(kTimeLimit);
    std::string model_description
        = hexaly_info_.optimizer->getModel().toString();
    hexaly_info_.optimizer->solve();
    double obtained_objective
        = hexaly_info_.optimizer->getModel().getObjective(0).getDoubleValue();
    return std::make_tuple(obtained_objective,
        std::numeric_limits<double>::quiet_NaN(),
        std::numeric_limits<double>::quiet_NaN());
}

void HexalyPerfectInfoEstimator::ResetHexalyInfo() {
    hexaly_info_ = HexalyInfo();
    hexaly_info_.optimizer = std::make_shared<hexaly::HexalyOptimizer>();
    hexaly_info_.if_group_accepted.clear();
    hexaly_info_.if_group_accepted.resize(summary_info_.n_groups);
    hexaly_info_.task_start.clear();
    hexaly_info_.task_start.resize(summary_info_.n_tasks);
    hexaly_info_.task_completion.clear();
    hexaly_info_.task_completion.resize(summary_info_.n_tasks);
    hexaly_info_.task_decline.clear();
    hexaly_info_.task_decline.resize(summary_info_.n_tasks);
    hexaly_info_.load_precedence.clear();
    hexaly_info_.due_difference.clear();
    hexaly_info_.due_difference.resize(summary_info_.n_tasks);
    hexaly_info_.task_machine_assignment.clear();
    hexaly_info_.task_machine_assignment.resize(kSetting.n_machines);
    for (unsigned idx_machine = 0; idx_machine < kSetting.n_machines; ++idx_machine) {
        hexaly_info_.task_machine_assignment[idx_machine].resize(summary_info_.n_tasks);
    }
    hexaly_info_.load_index.clear();
    hexaly_info_.load_index.resize(summary_info_.n_tasks);
    for (unsigned idx_task = 0; idx_task < summary_info_.n_tasks; ++idx_task) {
        hexaly_info_.load_index[idx_task].resize(summary_info_.n_tasks);
    }
}

SchedulingPlan HexalyPerfectInfoEstimator::SuggestSchedule(
            [[maybe_unused]] const SchedulingState& state,
            [[maybe_unused]] const Trajectory& trajectory) {
    throw std::logic_error("Needs implementation!");
}

void HexalyPerfectInfoEstimator::FormHexalyObjective(hexaly::HxModel* model) {
    std::vector<hexaly::HxExpression> acceptance_terms;
    for (unsigned idx_group = 0; idx_group < summary_info_.n_groups; ++idx_group) {
        const std::vector<SchedulingTask>& group = summary_info_.tasks[idx_group];
        hexaly::HxExpression group_acceptance = hexaly_info_.if_group_accepted[idx_group];
        hexaly::HxExpression weighted_acceptance = group_acceptance
            * model->createConstant(static_cast<double>(group.size()))
            * model->createConstant(summary_info_.price_per_task_group[idx_group]);
        acceptance_terms.push_back(weighted_acceptance);
    }
    std::vector<hexaly::HxExpression> decline_terms;
    std::vector<hexaly::HxExpression> delay_terms;
    for (unsigned idx_task = 0; idx_task < summary_info_.n_tasks; ++idx_task) {
        const SchedulingTask& task = summary_info_.index_to_task[idx_task];
        hexaly::HxExpression task_decline = hexaly_info_.task_decline[idx_task];
        decline_terms.push_back(model->createConstant(-task.decline_cost) * task_decline);
        hexaly::HxExpression due_delay = hexaly_info_.due_difference[idx_task];
        delay_terms.push_back(model->createConstant(-task.delay_cost) * due_delay);
    }
    hexaly::HxExpression sum_groups = SumExpressions(acceptance_terms, model);
    hexaly::HxExpression sum_delay = SumExpressions(delay_terms, model);
    hexaly::HxExpression sum_decline = SumExpressions(decline_terms, model);
    std::vector<hexaly::HxExpression> components = { sum_groups, sum_delay, sum_decline };
    hexaly_info_.objective = SumExpressions(components, model);
    model->maximize(hexaly_info_.objective);
}

void HexalyPerfectInfoEstimator::FormPrecedenceConstraints(hexaly::HxModel* model) {
    for (unsigned idx_lhs = 0; idx_lhs < summary_info_.n_tasks; ++idx_lhs) {
        const SchedulingTask& lhs_task = summary_info_.index_to_task[idx_lhs];
        hexaly::HxExpression lhs_start = hexaly_info_.task_start[idx_lhs];
        std::set<unsigned> compatible_lhs = std::set<unsigned>(
            lhs_task.compatible_machines.begin(), lhs_task.compatible_machines.end());
        for (unsigned idx_rhs = idx_lhs + 1; idx_rhs < summary_info_.n_tasks; ++idx_rhs) {
            const SchedulingTask& rhs_task = summary_info_.index_to_task[idx_rhs];
            hexaly::HxExpression rhs_start = hexaly_info_.task_start[idx_rhs];
            std::set<unsigned> compatible_rhs = std::set<unsigned>(
                rhs_task.compatible_machines.begin(), rhs_task.compatible_machines.end());
            unsigned idx_precedence = hexaly_info_.load_index[idx_lhs][idx_rhs];
            hexaly::HxExpression precedence_variable
                = hexaly_info_.load_precedence[idx_precedence];
            std::set<unsigned> common_machines;
            std::set_intersection(
                    compatible_lhs.begin(),
                    compatible_lhs.end(),
                    compatible_rhs.begin(),
                    compatible_rhs.end(),
                    std::inserter(common_machines, common_machines.end()));
            for (unsigned idx_machine : common_machines) {
                hexaly::HxExpression lhs_assignment
                    = hexaly_info_.task_machine_assignment[idx_machine][idx_lhs];
                hexaly::HxExpression rhs_assignment
                    = hexaly_info_.task_machine_assignment[idx_machine][idx_rhs];
                const double kHBound = summary_info_.upper_bound_completion_time;
                // s_k >= a_j(s_j + p_ij) - H(3  - y_ij - y_ik - z_jk),
                // precedence at same machine, k after j
                model->addConstraint(model->geq(
                            lhs_start,
                            (rhs_start + rhs_task.duration_per_machine[idx_machine])
                            - kHBound * (
                                3 - lhs_assignment - rhs_assignment - precedence_variable)));
                // s_j >= a_k(s_k + p_ik) - H(2 - y_ik - y_ij + z_jk),
                // precedence at same machine, j after k
                model->addConstraint(model->geq(
                        rhs_start,
                        (lhs_start + lhs_task.duration_per_machine[idx_machine])
                            - kHBound * (
                                2 - lhs_assignment - rhs_assignment + precedence_variable)));
            }
        }
    }
}

void HexalyPerfectInfoEstimator::FormStateConstraints(hexaly::HxModel* model) {
    for (const std::string& uuid_declined : summary_info_.declined_tasks) {
        unsigned idx_task = summary_info_.uuid_to_task_index[uuid_declined];
        hexaly::HxExpression task_decline = hexaly_info_.task_decline[idx_task];
        hexaly::HxExpression decline_constraint = model->eq(task_decline, 1);
        model->addConstraint(decline_constraint);
    }
    for (const std::string& uuid_allocated : summary_info_.allocated_tasks) {
        unsigned idx_task = summary_info_.uuid_to_task_index[uuid_allocated];
        Interval allocation = summary_info_.uuid_to_allocation[uuid_allocated];
        hexaly::HxExpression task_start = hexaly_info_.task_start[idx_task];
        model->addConstraint(model->eq(task_start, allocation.start_time));
        hexaly::HxExpression task_completion = hexaly_info_.task_completion[idx_task];
        model->addConstraint(model->eq(task_completion, allocation.completion_time));
        for (unsigned idx_machine = 0; idx_machine < kSetting.n_machines; ++idx_machine) {
            hexaly::HxExpression machine_assignment
                = hexaly_info_.task_machine_assignment[idx_machine][idx_task];
            if (idx_machine == allocation.machine_id) {
                model->addConstraint(model->eq(machine_assignment, 1));
            } else {
                model->addConstraint(model->eq(machine_assignment, 0));
            }
        }
    }
}

void HexalyPerfectInfoEstimator::FormTrajectoryConstraints(hexaly::HxModel* model) {
    // Only Accepted Are Assigned
    for (unsigned idx_group = 0; idx_group < summary_info_.n_groups; ++idx_group) {
        const std::vector<SchedulingTask>& group_of_tasks = summary_info_.tasks[idx_group];
        hexaly::HxExpression group_acceptance = hexaly_info_.if_group_accepted[idx_group];
        if (idx_group < summary_info_.n_preaccepted_groups) {
            model->addConstraint(model->eq(group_acceptance, 1));
        }
        for (const SchedulingTask& task : group_of_tasks) {
            std::vector<hexaly::HxExpression> components_assignment;
            unsigned idx_task = summary_info_.uuid_to_task_index[task.uuid];

            hexaly::HxExpression task_start = hexaly_info_.task_start[idx_task];
            // s_j >= l_j, Start after availability
            model->addConstraint(
                    model->geq(task_start, group_acceptance * task.availability_time));
            hexaly::HxExpression task_completion = hexaly_info_.task_completion[idx_task];
            hexaly::HxExpression due_difference = hexaly_info_.due_difference[idx_task];
            model->addConstraint(model->geq(due_difference, task_completion - task.due_time));

            for (unsigned idx_place = 0;
                    idx_place < task.compatible_machines.size(); ++idx_place) {
                unsigned idx_machine = task.compatible_machines[idx_place];
                hexaly::HxExpression machine_assignment
                    = hexaly_info_.task_machine_assignment[idx_machine][idx_task];
                // c_j >= s_j + y_ij * (p_ij + q_ij),
                // completion after start and processing + delivery
                model->addConstraint(model->geq(task_completion,
                            task_start + machine_assignment * (
                                task.duration_per_machine[idx_machine]
                                + task.delivery_per_machine[idx_machine])));
                components_assignment.push_back(machine_assignment);
            }
            hexaly::HxExpression total_machine_assignment
                = SumExpressions(components_assignment, model);

            for (unsigned idx_machine = 0; idx_machine < kSetting.n_machines; ++idx_machine) {
                if (std::find(task.compatible_machines.begin(), task.compatible_machines.end(),
                        idx_machine) == task.compatible_machines.end()) {
                    hexaly::HxExpression machine_assignment
                        = hexaly_info_.task_machine_assignment[idx_machine][idx_task];
                    // y_ij = 0 if machine not compatible
                    model->addConstraint(model->eq(machine_assignment, 0));
                }
            }

            // sum {y_ij} + d_j = a_g , assignment or decline if group accepted
            hexaly::HxExpression task_decline = hexaly_info_.task_decline[idx_task];
            model->addConstraint(model->eq(
                        total_machine_assignment + task_decline, group_acceptance));
            for (unsigned idy_task = idx_task + 1; idy_task < summary_info_.n_tasks; ++idy_task) {
                unsigned idx_precedence = hexaly_info_.load_index[idx_task][idy_task];
                hexaly::HxExpression precedence_variable
                    = hexaly_info_.load_precedence[idx_precedence];
                // z_jk <= a_g, z_ij can be 1 only if both tasks are accepted
                model->addConstraint(model->leq(precedence_variable, group_acceptance));
                // z_jk <= (1 - d_j), z_ij can be 1 only if both tasks are not declined
                model->addConstraint(model->leq(precedence_variable, (1 - task_decline)));
            }
        }
    }
}


void HexalyPerfectInfoEstimator::FormHexalyVariables(hexaly::HxModel* model) {
    for (unsigned idx_group = 0; idx_group < summary_info_.n_groups; ++idx_group) {
        if (kContinuousRelaxation) {
            hexaly_info_.if_group_accepted[idx_group] = model->floatVar(0., 1.);
        } else {
            hexaly_info_.if_group_accepted[idx_group] = model->intVar(0, 1);
        }
    }
    for (unsigned idx_task = 0; idx_task < summary_info_.n_tasks; ++idx_task) {
        SchedulingTask task = summary_info_.index_to_task[idx_task];
        if (kContinuousRelaxation) {
            hexaly_info_.task_decline[idx_task] = model->floatVar(0., 1.);
        } else {
            hexaly_info_.task_decline[idx_task] = model->intVar(0, 1);
        }
        hexaly_info_.task_start[idx_task]
            = model->floatVar(0, summary_info_.upper_bound_start_time);
        hexaly_info_.due_difference[idx_task]
            = model->floatVar(0, summary_info_.upper_bound_completion_time);
        hexaly_info_.task_completion[idx_task]
            = model->floatVar(0, summary_info_.upper_bound_completion_time);
    }
    for (unsigned idx_machine = 0; idx_machine < kSetting.n_machines; ++idx_machine) {
        for (unsigned idx_task = 0; idx_task < summary_info_.n_tasks; ++idx_task) {
            if (kContinuousRelaxation) {
                hexaly_info_.task_machine_assignment[idx_machine][idx_task]
                    = model->floatVar(0., 1.);
            } else {
                hexaly_info_.task_machine_assignment[idx_machine][idx_task]
                    = model->intVar(0, 1);
            }
        }
    }
    unsigned idx_precedence = 0;
    for (unsigned lhs_task_idx = 0; lhs_task_idx < summary_info_.n_tasks; ++lhs_task_idx) {
        for (unsigned rhs_task_idx = lhs_task_idx + 1;
                rhs_task_idx < summary_info_.n_tasks; ++rhs_task_idx) {
            hexaly::HxExpression precedence_variable;
            if (kContinuousRelaxation) {
                precedence_variable = model->floatVar(0., 1.);
            } else {
                precedence_variable = model->intVar(0, 1);
            }
            assert(hexaly_info_.load_precedence.size() == idx_precedence);
            hexaly_info_.load_precedence.push_back(precedence_variable);
            hexaly_info_.load_index[lhs_task_idx][rhs_task_idx] = idx_precedence;
            hexaly_info_.load_index[rhs_task_idx][lhs_task_idx] = idx_precedence;
            ++idx_precedence;
        }
    }
}

#endif

} // namespace accurate

