#include <numeric>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <cassert>

#include "../data/setting.h"
#include "../schedule/scheduling_state.h"
#include "../schedule/scheduling_task.h"
#include "../estimation/estimator_interface.h"

namespace accurate {

void IPerfectInfoEstimator::ResetSummaryInfo() {
    summary_info_ = SummaryInfo();
}

void IPerfectInfoEstimator::ProcessStateInfo(const SchedulingState& state) {
    for (unsigned idx = 0; idx < state.request_history.size(); ++idx) {
        summary_info_.tasks.push_back(state.request_history[idx]);
        summary_info_.price_per_task_group.push_back(state.price_history[idx]);
        summary_info_.period_ids.push_back(state.period_history[idx]);
        ++summary_info_.n_preaccepted_groups;
        ++summary_info_.n_groups;
        for (const auto& task : state.request_history[idx]) {
            summary_info_.uuid_to_task_index[task.uuid] = summary_info_.n_tasks;
            summary_info_.index_to_task.push_back(task);
            ++summary_info_.n_tasks;
        }
    }
    for (const auto& task : state.declined_tasks) {
        summary_info_.declined_tasks.insert(task.uuid);
    }
    for (const auto& task : state.allocated_tasks) {
        summary_info_.allocated_tasks.insert(task.uuid);
    }
    for (unsigned machine_id = 0; machine_id < kSetting.n_machines; ++machine_id) {
        for (const Interval& interval : state.task_allocation[machine_id]) {
            summary_info_.uuid_to_allocation[interval.task.uuid] = interval;
        }
    }
}

void IPerfectInfoEstimator::ComputeTimeMargins(
        const SchedulingState& state, const Trajectory& trajectory) {
    for (unsigned idx_place = 0; idx_place < state.request_history.size(); ++idx_place) {
        for (const auto& task : state.request_history[idx_place]) {
            summary_info_.upper_bound_start_time += *std::max_element(
                    task.duration_per_machine.begin(), task.duration_per_machine.end());
            summary_info_.upper_bound_start_time += task.wait_time_after_order;
            summary_info_.upper_bound_completion_time += *std::max_element(
                    task.delivery_per_machine.begin(), task.delivery_per_machine.end());
        }
    }
    for (unsigned idx_period = state.state_period; idx_period < kSetting.n_periods; ++idx_period) {
        if (trajectory.sampled_orders.find(idx_period) != trajectory.sampled_orders.end()) {
            const OrderType& order = trajectory.sampled_orders.at(idx_period);
            summary_info_.upper_bound_start_time += *std::max_element(
                    order.duration_per_machine.begin(), order.duration_per_machine.end())
                * order.count;
            summary_info_.upper_bound_start_time += order.availability_time;
            summary_info_.upper_bound_completion_time += *std::max_element(
                    order.delivery_per_machine.begin(), order.delivery_per_machine.end())
                * order.count;
        }
    }
    summary_info_.upper_bound_start_time  += std::accumulate(
            kSetting.period_durations.begin(), kSetting.period_durations.end(), 0.);
    summary_info_.upper_bound_completion_time += summary_info_.upper_bound_start_time;
}

void IPerfectInfoEstimator::ProcessTrajectoryInfo(
        const Trajectory& trajectory, unsigned state_period) {
    for (unsigned idx_period = state_period; idx_period < kSetting.n_periods; ++idx_period) {
        if (trajectory.sampled_orders.find(idx_period) != trajectory.sampled_orders.end()) {
            const OrderType& order = trajectory.sampled_orders.at(idx_period);
            double willingness_to_pay = trajectory.willingness_to_pay.at(idx_period);
            double price_decision = willingness_to_pay;
            if (!kContinuousPrices) {
                std::vector<double> possible_prices
                    = kSetting.price_ranges[idx_period][order.idx_type];
                std::vector<double> feasible_prices;
                for (const auto& point_price : possible_prices) {
                    if (point_price < willingness_to_pay) {
                        feasible_prices.push_back(point_price);
                    }
                }
                if (feasible_prices.size()) {
                    price_decision = *std::max_element(
                            feasible_prices.begin(), feasible_prices.end());
                } else {
                    price_decision = *std::max_element(
                            possible_prices.begin(), possible_prices.end());
                }
            }
            constexpr double kEps = 1e-2;
            if (price_decision <= willingness_to_pay + kEps) {
                std::vector<SchedulingTask> order_tasks = BuildTasksFromOrder(
                        order, price_decision, idx_period);
                summary_info_.price_per_task_group.push_back(price_decision);
                summary_info_.tasks.push_back(order_tasks);
                summary_info_.period_ids.push_back(idx_period);
                ++summary_info_.n_groups;
                for (const auto& task : order_tasks) {
                    summary_info_.uuid_to_task_index[task.uuid] = summary_info_.n_tasks;
                    summary_info_.index_to_task.push_back(task);
                    ++summary_info_.n_tasks;
                }
            }
        }
    }
}

} //namespace accurate

