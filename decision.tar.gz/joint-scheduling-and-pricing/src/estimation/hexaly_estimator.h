#pragma once


#include <vector>
#include <tuple>

#ifdef RESEARCH_MODE
#include <optimizer/hexalyoptimizer.h>
#endif

#include "../estimation/estimator_interface.h"
#include "../data/setting.h"
#include "../schedule/scheduling_state.h"
#include "../schedule/scheduler_interface.h"


namespace accurate {

#ifdef RESEARCH_MODE
struct HexalyInfo {
    std::shared_ptr<hexaly::HexalyOptimizer> optimizer;
    hexaly::HxExpression objective;
    std::vector<hexaly::HxExpression> if_group_accepted;
    std::vector<hexaly::HxExpression> task_start;
    std::vector<hexaly::HxExpression> task_completion;
    std::vector<hexaly::HxExpression> task_decline;
    std::vector<std::vector<hexaly::HxExpression>> task_machine_assignment;
    std::vector<std::vector<unsigned>> load_index;
    std::vector<hexaly::HxExpression> load_precedence;
    std::vector<hexaly::HxExpression> due_difference;
};



class HexalyPerfectInfoEstimator : public IPerfectInfoEstimator {
public:
    HexalyPerfectInfoEstimator(
            const Setting& setting,
            bool assume_continuous_prices,
            bool continuous_relaxation,
            unsigned time_limit);
    virtual std::tuple<double, double, double> EvaluateTrajectory(
            const SchedulingState& state, const Trajectory& trajectory) override final;
    virtual SchedulingPlan SuggestSchedule(
            const SchedulingState& state, const Trajectory& trajectory) override final;
    virtual ~HexalyPerfectInfoEstimator() = default;

private:
    void ResetHexalyInfo();
    void FormHexalyVariables(hexaly::HxModel* model);
    void FormTrajectoryConstraints(hexaly::HxModel* model);
    void FormPrecedenceConstraints(hexaly::HxModel* model);
    void FormStateConstraints(hexaly::HxModel* model);
    void FormHexalyObjective(hexaly::HxModel* model);

private:
    HexalyInfo hexaly_info_;
};
#endif

} //namespace accurate

