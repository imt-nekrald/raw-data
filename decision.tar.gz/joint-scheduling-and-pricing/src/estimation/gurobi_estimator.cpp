#include <vector>
#include <algorithm>
#include <set>
#include <stdexcept>
#include <thread>
#include <tuple>

#ifdef RESEARCH_MODE
#include <gurobi_c++.h>
#endif

#include "../data/setting.h"
#include "../schedule/scheduling_task.h"
#include "../schedule/scheduling_state.h"
#include "../estimation/estimator_interface.h"
#include "../estimation/gurobi_estimator.h"


namespace accurate {

#ifdef RESEARCH_MODE

GurobiPerfectInfoEstimator::GurobiPerfectInfoEstimator(
        const Setting& setting,
        bool assume_continuous_prices,
        bool continuous_relaxation,
        unsigned time_limit)
        : IPerfectInfoEstimator(
                setting,
                assume_continuous_prices,
                continuous_relaxation,
                time_limit) {}

std::tuple<double, double, double> GurobiPerfectInfoEstimator::EvaluateTrajectory(
        const SchedulingState& state, const Trajectory& trajectory) {
    ResetSummaryInfo();
    ProcessStateInfo(state);
    ProcessTrajectoryInfo(trajectory, state.state_period);
    ComputeTimeMargins(state, trajectory);
    ResetGurobiInfo();
    FormGurobiVariables();
    FormTrajectoryConstraints();
    FormPrecedenceConstraints();
    FormStateConstraints();
    FormGurobiObjective();
    gurobi_info_.model->optimize();
    double achieved_objective = gurobi_info_.model->get(GRB_DoubleAttr_ObjVal);
    double best_bound = gurobi_info_.model->get(GRB_DoubleAttr_ObjBound);
    double mip_gap = gurobi_info_.model->get(GRB_DoubleAttr_MIPGap);
    return std::make_tuple(achieved_objective, best_bound, mip_gap);
}

SchedulingPlan GurobiPerfectInfoEstimator::SuggestSchedule(
        [[maybe_unused]] const SchedulingState& state,
        [[maybe_unused]] const Trajectory& trajectory) {
    throw std::logic_error("Needs implementation!");
}

void GurobiPerfectInfoEstimator::FormGurobiObjective() {
    GRBLinExpr objective = 0.;
    for (unsigned idx_group = 0; idx_group < summary_info_.n_groups; ++idx_group) {
        const std::vector<SchedulingTask>& group = summary_info_.tasks[idx_group];
        GRBVar group_acceptance = gurobi_info_.if_group_accepted[idx_group];
        objective += group_acceptance * static_cast<double>(group.size())
            * summary_info_.price_per_task_group[idx_group];
    }

    for (unsigned idx_task = 0; idx_task < summary_info_.n_tasks; ++idx_task) {
        const SchedulingTask& task = summary_info_.index_to_task[idx_task];
        GRBVar task_decline = gurobi_info_.task_decline[idx_task];
        objective -= task_decline * task.decline_cost;
        GRBVar due_delay = gurobi_info_.due_difference[idx_task];
        objective -= due_delay * task.delay_cost;
    }
    gurobi_info_.model->setObjective(objective, GRB_MAXIMIZE);
}

void GurobiPerfectInfoEstimator::FormTrajectoryConstraints() {
    // Only Accepted Are Assigned
    for (unsigned idx_group = 0; idx_group < summary_info_.n_groups; ++idx_group) {
        const std::vector<SchedulingTask>& group_of_tasks = summary_info_.tasks[idx_group];
        GRBVar group_acceptance = gurobi_info_.if_group_accepted[idx_group];
        if (idx_group < summary_info_.n_preaccepted_groups) {
                gurobi_info_.model->addConstr(group_acceptance == 1.);
        }
        for (const SchedulingTask& task : group_of_tasks) {
            GRBLinExpr total_machine_assignment = 0.;
            unsigned idx_task = summary_info_.uuid_to_task_index[task.uuid];

            GRBVar task_start = gurobi_info_.task_start[idx_task];
            // s_j >= l_j, Start after availability
            gurobi_info_.model->addConstr(task_start >= group_acceptance * task.availability_time);
            GRBVar task_completion = gurobi_info_.task_completion[idx_task];
            GRBVar due_difference = gurobi_info_.due_difference[idx_task];
            gurobi_info_.model->addConstr(due_difference >= task_completion - task.due_time);

            GRBVar task_decline = gurobi_info_.task_decline[idx_task];
            for (unsigned idx_place = 0;
                    idx_place < task.compatible_machines.size(); ++idx_place) {
                unsigned idx_machine = task.compatible_machines[idx_place];
                GRBVar machine_assignment
                    = gurobi_info_.task_machine_assignment[idx_machine][idx_task];
                // c_j >= s_j + y_ij * (p_ij + q_ij),
                // completion after start and processing + delivery
                gurobi_info_.model->addConstr(task_completion >= task_start
                        + machine_assignment * (
                            task.duration_per_machine[idx_machine]
                            + task.delivery_per_machine[idx_machine]));
                total_machine_assignment += machine_assignment;
            }

            for (unsigned idx_machine = 0; idx_machine < kSetting.n_machines; ++idx_machine) {
                if (std::find(task.compatible_machines.begin(), task.compatible_machines.end(),
                        idx_machine) == task.compatible_machines.end()) {
                    GRBVar machine_assignment
                        = gurobi_info_.task_machine_assignment[idx_machine][idx_task];
                    // y_ij = 0 if machine not compatible
                    gurobi_info_.model->addConstr(machine_assignment == 0.);
                }
            }

            // sum {y_ij} + d_j = a_g , assignment or decline if group accepted
            gurobi_info_.model->addConstr(
                    total_machine_assignment + task_decline == group_acceptance);
            for (unsigned idy_task = idx_task + 1; idy_task < summary_info_.n_tasks; ++idy_task) {
                unsigned idx_precedence = gurobi_info_.load_index[idx_task][idy_task];
                GRBVar precedence_variable = gurobi_info_.load_precedence[idx_precedence];
                // z_jk <= a_g, z_ij can be 1 only if both tasks are accepted
                gurobi_info_.model->addConstr(precedence_variable <= group_acceptance);
                // z_jk <= (1 - d_j), z_ij can be 1 only if both tasks are not declined
                gurobi_info_.model->addConstr(precedence_variable <= (1 - task_decline));
            }
        }
    }
}

void GurobiPerfectInfoEstimator::FormPrecedenceConstraints() {
    for (unsigned idx_lhs = 0; idx_lhs < summary_info_.n_tasks; ++idx_lhs) {
        const SchedulingTask& lhs_task = summary_info_.index_to_task[idx_lhs];
        GRBVar lhs_start = gurobi_info_.task_start[idx_lhs];
        std::set<unsigned> compatible_lhs = std::set<unsigned>(
                lhs_task.compatible_machines.begin(), lhs_task.compatible_machines.end());
        for (unsigned idx_rhs = idx_lhs + 1; idx_rhs < summary_info_.n_tasks; ++idx_rhs) {
            const SchedulingTask& rhs_task = summary_info_.index_to_task[idx_rhs];
            GRBVar rhs_start = gurobi_info_.task_start[idx_rhs];
            std::set<unsigned> compatible_rhs = std::set<unsigned>(
                rhs_task.compatible_machines.begin(), rhs_task.compatible_machines.end());
            unsigned idx_precedence = gurobi_info_.load_index[idx_lhs][idx_rhs];
            GRBVar precedence_variable = gurobi_info_.load_precedence[idx_precedence];
            std::set<unsigned> common_machines;
            std::set_intersection(compatible_lhs.begin(), compatible_lhs.end(),
                    compatible_rhs.begin(), compatible_rhs.end(),
                    std::inserter(common_machines, common_machines.end()));
            for (unsigned idx_machine : common_machines) {
                GRBVar lhs_assignment = gurobi_info_.task_machine_assignment[idx_machine][idx_lhs];
                GRBVar rhs_assignment = gurobi_info_.task_machine_assignment[idx_machine][idx_rhs];
                // s_k >= a_j(s_j + p_ij) - H(3  - y_ij - y_ik - z_jk),
                // precedence at same machine, k after j
                gurobi_info_.model->addConstr(lhs_start >= (rhs_start
                            + rhs_task.duration_per_machine[idx_machine])
                        - summary_info_.upper_bound_start_time
                        * (3 - lhs_assignment - rhs_assignment - precedence_variable));
                // s_j >= a_k(s_k + p_ik) - H(2 - y_ik - y_ij + z_jk),
                // precedence at same machine, j after k
                gurobi_info_. model->addConstr(rhs_start >= (lhs_start
                            + lhs_task.duration_per_machine[idx_machine])
                        - summary_info_.upper_bound_start_time
                        * (2 - lhs_assignment - rhs_assignment + precedence_variable));
            }
        }
    }
}

void GurobiPerfectInfoEstimator::FormStateConstraints() {
    for (const std::string& uuid_declined : summary_info_.declined_tasks) {
        unsigned idx_task = summary_info_.uuid_to_task_index[uuid_declined];
        GRBVar task_decline = gurobi_info_.task_decline[idx_task];
        gurobi_info_.model->addConstr(task_decline == 1.);
    }
    for (const std::string& uuid_allocated: summary_info_.allocated_tasks) {
        unsigned idx_task = summary_info_.uuid_to_task_index[uuid_allocated];
        Interval allocation = summary_info_.uuid_to_allocation[uuid_allocated];
        GRBVar task_start = gurobi_info_.task_start[idx_task];
        gurobi_info_.model->addConstr(task_start == allocation.start_time);
        GRBVar task_completion = gurobi_info_.task_completion[idx_task];
        gurobi_info_.model->addConstr(task_completion == allocation.completion_time);
        for (unsigned idx_machine = 0; idx_machine < kSetting.n_machines; ++idx_machine) {
            GRBVar machine_assignment
                = gurobi_info_.task_machine_assignment[idx_machine][idx_task];
            if (idx_machine == allocation.machine_id) {
                gurobi_info_.model->addConstr(machine_assignment == 1.);
            } else {
                gurobi_info_.model->addConstr(machine_assignment == 0.);
            }
        }
    }
}

void GurobiPerfectInfoEstimator::FormGurobiVariables() {
    for (unsigned idx_group = 0; idx_group < summary_info_.n_groups; ++idx_group) {
        unsigned idx_period = summary_info_.period_ids[idx_group];
        if (kContinuousRelaxation) {
            gurobi_info_.if_group_accepted[idx_group] = gurobi_info_.model->addVar(
                    0., 1., 1., GRB_CONTINUOUS, "acceptance_period_" + std::to_string(idx_period));
        } else {
            gurobi_info_.if_group_accepted[idx_group] = gurobi_info_.model->addVar(
                    0., 1., 1., GRB_BINARY, "acceptance_period_" + std::to_string(idx_period));
        }
    }
    for (unsigned idx_task = 0; idx_task < summary_info_.n_tasks; ++idx_task) {
        SchedulingTask task = summary_info_.index_to_task[idx_task];
        if (kContinuousRelaxation) {
            gurobi_info_.task_decline[idx_task] = gurobi_info_.model->addVar(
                    0., 1., 0., GRB_CONTINUOUS, "task_decline_" + std::to_string(idx_task));

        } else {
            gurobi_info_.task_decline[idx_task] = gurobi_info_.model->addVar(
                    0., 1., 0., GRB_BINARY, "task_decline_" + std::to_string(idx_task));
        }
        gurobi_info_.task_start[idx_task] = gurobi_info_.model->addVar(
                0., summary_info_.upper_bound_start_time, 0., GRB_CONTINUOUS,
                "task_start_" + std::to_string(idx_task));
        gurobi_info_.task_completion[idx_task] = gurobi_info_.model->addVar(
                0., summary_info_.upper_bound_completion_time, 0., GRB_CONTINUOUS,
                "task_completion_" + std::to_string(idx_task));
        gurobi_info_.due_difference[idx_task] = gurobi_info_.model->addVar(
                0., summary_info_.upper_bound_completion_time, 0., GRB_CONTINUOUS,
                "due_difference_" + std::to_string(idx_task));
    }
    for (unsigned idx_machine = 0; idx_machine < kSetting.n_machines; ++idx_machine) {
        for (unsigned idx_task = 0; idx_task < summary_info_.n_tasks; ++idx_task) {
            if (kContinuousRelaxation) {
                gurobi_info_.task_machine_assignment[idx_machine][idx_task]
                    = gurobi_info_.model->addVar(0., 1., 0., GRB_CONTINUOUS,
                            "processing_task_" + std::to_string(idx_task)
                            + "_on_machine_" + std::to_string(idx_machine));
            } else {
                gurobi_info_.task_machine_assignment[idx_machine][idx_task]
                    = gurobi_info_.model->addVar(0., 1., 0., GRB_BINARY,
                            "processing_task_" + std::to_string(idx_task)
                            + "_on_machine_" + std::to_string(idx_machine));
            }
        }
    }
    unsigned idx_precedence = 0;
    for (unsigned lhs_task_idx = 0; lhs_task_idx < summary_info_.n_tasks; ++lhs_task_idx) {
        for (unsigned rhs_task_idx = lhs_task_idx + 1;
                rhs_task_idx < summary_info_.n_tasks; ++rhs_task_idx) {
            GRBVar precedence_variable;
            if (kContinuousRelaxation) {
                precedence_variable = gurobi_info_.model->addVar(
                        0., 1., 0., GRB_CONTINUOUS,
                        "precedence_" + std::to_string(lhs_task_idx)
                        + "_to_" + std::to_string(rhs_task_idx));
            } else {
                precedence_variable = gurobi_info_.model->addVar(
                        0., 1., 0., GRB_BINARY,
                        "precedence_" + std::to_string(lhs_task_idx)
                        + "_to_" + std::to_string(rhs_task_idx));
            }
            gurobi_info_.load_precedence.push_back(precedence_variable);
            gurobi_info_.load_index[lhs_task_idx][rhs_task_idx] = idx_precedence;
            gurobi_info_.load_index[rhs_task_idx][lhs_task_idx] = idx_precedence;
            ++idx_precedence;
        }
    }
}

void GurobiPerfectInfoEstimator::ResetGurobiInfo() {
    gurobi_info_ = GurobiInfo();
    gurobi_info_.if_group_accepted.clear();
    gurobi_info_.if_group_accepted.resize(summary_info_.n_groups);
    gurobi_info_.task_start.clear();
    gurobi_info_.task_start.resize(summary_info_.n_tasks);
    gurobi_info_.task_completion.clear();
    gurobi_info_.task_completion.resize(summary_info_.n_tasks);
    gurobi_info_.task_decline.clear();
    gurobi_info_.task_decline.resize(summary_info_.n_tasks);
    gurobi_info_.load_precedence.clear();
    gurobi_info_.due_difference.clear();
    gurobi_info_.due_difference.resize(summary_info_.n_tasks);
    gurobi_info_.task_machine_assignment.clear();
    gurobi_info_.task_machine_assignment.resize(kSetting.n_machines);
    for (unsigned idx_machine = 0; idx_machine < kSetting.n_machines; ++idx_machine) {
        gurobi_info_.task_machine_assignment[idx_machine].resize(summary_info_.n_tasks);
    }
    gurobi_info_.load_index.clear();
    gurobi_info_.load_index.resize(summary_info_.n_tasks);
    for (unsigned idx_task = 0; idx_task < summary_info_.n_tasks; ++idx_task) {
        gurobi_info_.load_index[idx_task].resize(summary_info_.n_tasks);
    }
    GRBEnv environment = GRBEnv(true);
    environment.set("LogFile", "gurobi_" + GenerateUUID() + ".log");
    environment.set(GRB_DoubleParam_TimeLimit, kTimeLimit);
    environment.start();
    unsigned threads = std::max(1u, std::thread::hardware_concurrency());
    environment.set(GRB_IntParam_Threads, static_cast<int>(threads));
    gurobi_info_.model = std::make_shared<GRBModel>(environment);
}

#endif

} // namespace accurate

