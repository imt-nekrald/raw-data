#include <memory>
#include <vector>

#include "../evaluate/scorer.h"
#include "../evaluate/trajectory_manager.h"
#include "../data/setting.h"
#include "../policy/price_interface.h"
#include "../schedule/scheduling_state.h"
#include "../schedule/scheduling_task.h"
#include "../evaluate/confidence.h"


namespace accurate {

SamplingScorer::SamplingScorer(
        const Setting& setting,
        std::shared_ptr<ITrajectoryManager> trajectory_manager)
        : trajectory_manager_(trajectory_manager)
        , kSetting(setting) {

}

ConfidenceResult SamplingScorer::GetScore(
        [[maybe_unused]] unsigned next_period,
        [[maybe_unused]] double prefix_score,
        std::shared_ptr<IPolicy> policy) const {
    SchedulingState state = policy->GetSchedulingState();
    std::vector<double> revenues;
    unsigned n_trajectories = trajectory_manager_->GetTrajectoriesCount();
    for (unsigned idx_evaluation = 0; idx_evaluation < n_trajectories; ++idx_evaluation) {
        policy->SetSchedulingState(state);
        const Trajectory& trajectory = trajectory_manager_->ProvideTrajectory(idx_evaluation);
        double accumulated_time = state.state_time;
        for (unsigned idx_period = state.state_period;
                idx_period < kSetting.n_periods; ++idx_period) {
            std::vector<SchedulingTask> order_tasks;
            if (trajectory.sampled_orders.find(idx_period) != trajectory.sampled_orders.end()) {
                OrderType order = trajectory.sampled_orders.at(idx_period);
                double willingness_to_pay = trajectory.willingness_to_pay.at(idx_period);
                double proposed_price = policy->SuggestPrice(idx_period, order);
                if (proposed_price < willingness_to_pay) {
                    order_tasks = BuildTasksFromOrder(order, proposed_price, accumulated_time);
                }
            }
            policy->UpdateSchedule(idx_period, order_tasks);
            accumulated_time += kSetting.period_durations[idx_period];
        }
        policy->FinalizeSchedule();
        revenues.push_back(policy->GetSchedulingState().allocated_revenue);
    }
    ConfidenceInterval revenue_interval = BuildConfidenceInterval(revenues);
    ConfidenceResult confidence_result;
    confidence_result.revenue_ = revenue_interval;
    return confidence_result;
}

void SamplingScorer::ResampleTrajectories() {
    trajectory_manager_->ResampleTrajectories();
}

SolverScorer::SolverScorer(
        const Setting& setting,
        std::shared_ptr<ITrajectoryManager> trajectory_manager,
        std::shared_ptr<IPerfectInfoEstimator> estimator)
        : trajectory_manager_(trajectory_manager)
        , estimator_(estimator)
        , kSetting(setting) {}

ConfidenceResult SolverScorer::GetScore(const SchedulingState& state) const {
    std::vector<double> estimates;
    std::vector<double> gaps;
    std::vector<double> bounds;
    unsigned n_trajectories = trajectory_manager_->GetTrajectoriesCount();
    for (unsigned idx_evaluation = 0; idx_evaluation < n_trajectories; ++idx_evaluation) {
        const Trajectory& trajectory = trajectory_manager_->ProvideTrajectory(idx_evaluation);
        auto evaluation_result = estimator_->EvaluateTrajectory(state, trajectory);
        estimates.push_back(std::get<0>(evaluation_result));
        bounds.push_back(std::get<1>(evaluation_result));
        gaps.push_back(std::get<2>(evaluation_result));
    }

    ConfidenceInterval revenue_interval = BuildConfidenceInterval(estimates);
    ConfidenceInterval gap_interval = BuildConfidenceInterval(gaps);
    ConfidenceInterval bound_interval = BuildConfidenceInterval(bounds);
    ConfidenceResult expected_estimation;
    expected_estimation.revenue_ = revenue_interval;
    expected_estimation.gap_ = gap_interval;
    expected_estimation.bound_ = bound_interval;
    return expected_estimation;
}

void SolverScorer::ResampleTrajectories() {
    trajectory_manager_->ResampleTrajectories();
}

} // namespace accurate

