#pragma once

#include <vector>

namespace accurate {

struct ConfidenceInterval {
    double lower_bound_;
    double average_;
    double upper_bound_;
    std::vector<double> observations_;
};


struct ConfidenceResult {
    ConfidenceInterval revenue_;
    ConfidenceInterval gap_;
    ConfidenceInterval bound_;
};

ConfidenceInterval BuildConfidenceInterval(const std::vector<double>& observations);

} // namespace accurate
