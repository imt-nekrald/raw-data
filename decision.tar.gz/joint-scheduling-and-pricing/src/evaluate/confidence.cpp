#include <vector>
#include <boost/math/statistics/univariate_statistics.hpp>

#include "../evaluate/confidence.h"

namespace accurate {

ConfidenceInterval BuildConfidenceInterval(const std::vector<double>& observations) {
    double variance = boost::math::statistics::variance(observations);
    double average = boost::math::statistics::mean(observations);
    ConfidenceInterval interval;
    interval.average_ = average;
    interval.lower_bound_ = average - 1.96 * std::sqrt(variance / observations.size());
    interval.upper_bound_ = average + 1.96 * std::sqrt(variance / observations.size());
    interval.observations_ = observations;
    return interval;
}

} // namespace accurate
