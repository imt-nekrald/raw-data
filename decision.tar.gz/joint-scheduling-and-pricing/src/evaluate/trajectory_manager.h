#pragma once

#include <vector>
#include <memory>

#include "../data/setting.h"
#include "../data/sampler.h"


namespace accurate {

class ITrajectoryManager {
public:
    ITrajectoryManager(
            const Setting& kSetting,
            unsigned n_trajectories,
            unsigned n_fast_trajectories);
    virtual void ResampleTrajectories() = 0;
    unsigned GetTrajectoriesCount() const {
        return fast_mode_? kFastTrajectoriesCount : kTrajectoriesCount;
    }
    Trajectory ProvideTrajectory(unsigned idx) {
        return  evaluation_trajectories_.at(idx);
    }
    std::vector<Trajectory> RequestAllTrajectories() const {
        return evaluation_trajectories_;
    }
    void SetFastMode(bool fast_flag) {
        fast_mode_ = fast_flag;
    }
    bool GetFastMode() {
        return fast_mode_;
    }
    virtual ~ITrajectoryManager() = default;

protected:
    const Setting kSetting;
    const unsigned kFastTrajectoriesCount;
    const unsigned kTrajectoriesCount;
    bool fast_mode_ = false;
    std::vector<Trajectory> evaluation_trajectories_;
};


class RandomTrajectoryManager : public ITrajectoryManager {
public:
    RandomTrajectoryManager(
            const Setting& kSetting,
            unsigned n_trajectories,
            std::shared_ptr<Sampler> ptr_sampler,
            unsigned n_fast_trajectories);
    virtual void ResampleTrajectories() override final;
    virtual ~RandomTrajectoryManager() = default;

private:
    std::shared_ptr<Sampler> sampler;
};

class StaticTrajectoryManager: public ITrajectoryManager {
public:
    StaticTrajectoryManager(
            const Setting& kSetting,
            std::vector<Trajectory> trajectories);
    virtual void ResampleTrajectories() override final;
    virtual ~StaticTrajectoryManager() = default;
};


} // namespace accurate

