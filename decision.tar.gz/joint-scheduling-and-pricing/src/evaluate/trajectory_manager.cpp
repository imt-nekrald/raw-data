#include "../evaluate/trajectory_manager.h"


namespace accurate {

ITrajectoryManager::ITrajectoryManager(
        const Setting& setting,
        unsigned n_trajectories,
        unsigned n_fast_trajectories)
        : kSetting(setting)
        , kFastTrajectoriesCount(n_fast_trajectories)
        , kTrajectoriesCount(n_trajectories) {
}

RandomTrajectoryManager::RandomTrajectoryManager(
        const Setting& setting,
        unsigned n_trajectories,
        std::shared_ptr<Sampler> ptr_sampler,
        unsigned n_fast_trajectories)
        : ITrajectoryManager(setting, n_trajectories, n_fast_trajectories)
        , sampler(ptr_sampler) {
    ResampleTrajectories();
}

void RandomTrajectoryManager::ResampleTrajectories() {
    unsigned n_trajectories = fast_mode_ ? kFastTrajectoriesCount : kTrajectoriesCount;
    evaluation_trajectories_.clear();
    for (unsigned idx_trajectory = 0; idx_trajectory < n_trajectories; ++idx_trajectory) {
        evaluation_trajectories_.push_back(sampler->PrepareSample());
    }
}

StaticTrajectoryManager::StaticTrajectoryManager(
        const Setting& setting,
        std::vector<Trajectory> trajectories)
        : ITrajectoryManager(
                setting,
                static_cast<unsigned>(trajectories.size()),
                static_cast<unsigned>(trajectories.size())) {
    evaluation_trajectories_ = trajectories;
}

void StaticTrajectoryManager::ResampleTrajectories() {
}

}// namespace accurate
