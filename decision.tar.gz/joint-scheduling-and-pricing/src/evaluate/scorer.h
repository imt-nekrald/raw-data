#pragma once

#include <memory>

#include "../data/setting.h"
#include "../policy/price_interface.h"
#include "../estimation/estimator_interface.h"
#include "../evaluate/trajectory_manager.h"
#include "../evaluate/confidence.h"

namespace accurate {


class IPolicyScorer {
public:
    virtual ConfidenceResult GetScore(
            unsigned next_period,
            double prefix_score,
            std::shared_ptr<IPolicy> policy) const = 0;
    virtual void ResampleTrajectories() = 0;
    virtual ~IPolicyScorer() = default;
};


class SamplingScorer : public IPolicyScorer {
public:
    SamplingScorer(
            const Setting& kSetting,
            std::shared_ptr<ITrajectoryManager> trajectory_manager);
    virtual ConfidenceResult GetScore(
            unsigned next_period,
            double prefix_score,
            std::shared_ptr<IPolicy> policy) const override final;
    virtual void ResampleTrajectories() override final;
    virtual ~SamplingScorer() = default;

private:
    std::shared_ptr<ITrajectoryManager> trajectory_manager_;
    const Setting kSetting;
};


class IStateScorer {
public:
    virtual ConfidenceResult GetScore(const SchedulingState& state) const = 0;
    virtual void ResampleTrajectories() = 0;
    virtual ~IStateScorer() = default;
};


class SolverScorer : public IStateScorer {
public:
    SolverScorer(
            const Setting& kSetting,
            std::shared_ptr<ITrajectoryManager> trajectory_manager,
            std::shared_ptr<IPerfectInfoEstimator> estimator);
    virtual ConfidenceResult GetScore(const SchedulingState& state) const override final;
    virtual void ResampleTrajectories() override final;
    virtual ~SolverScorer() = default;

private:
    std::shared_ptr<ITrajectoryManager> trajectory_manager_;
    std::shared_ptr<IPerfectInfoEstimator> estimator_;
    const Setting kSetting;
};


} // namespace accurate
