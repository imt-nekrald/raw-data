#include <json/json.h>
#include "../schedule/scheduling_state.h"

namespace accurate {


Json::Value IntervalToJsonValue(
        const Interval& interval) {
    Json::Value interval_storage;
    interval_storage["task"] = SchedulingTaskToJsonValue(interval.task);
    interval_storage["start-time"] = interval.start_time;
    interval_storage["completion-time"] = interval.completion_time;
    interval_storage["delay-penalty"] = interval.delay_penalty;
    interval_storage["machine-id"] = interval.machine_id;
    return interval_storage;
};

Interval JsonValueToInterval(
        const Json::Value& json_interval) {
    Interval interval;
    interval.task = JsonValueToSchedulingTask(json_interval["task"]);
    interval.start_time = json_interval["start-time"].asDouble();
    interval.completion_time = json_interval["completion-time"].asDouble();
    interval.delay_penalty = json_interval["delay-penalty"].asDouble();
    interval.machine_id = json_interval["machine-id"].asUInt();
    return interval;
};

Json::Value SchedulingStateToJsonValue(
        const SchedulingState& scheduling_state) {
    Json::Value state_storage;
    state_storage["state-time"] = scheduling_state.state_time;
    state_storage["allocated-revenue"] = scheduling_state.allocated_revenue;
    state_storage["state-period"] = scheduling_state.state_period;
    Json::Value flexible_array(Json::arrayValue);
    Json::Value allocated_array(Json::arrayValue);
    Json::Value declined_array(Json::arrayValue);
    for (const SchedulingTask& scheduling_task : scheduling_state.flexible_tasks) {
        flexible_array.append(SchedulingTaskToJsonValue(scheduling_task));
    }
    for (const SchedulingTask& scheduling_task : scheduling_state.allocated_tasks) {
        allocated_array.append(SchedulingTaskToJsonValue(scheduling_task));
    }
    for (const SchedulingTask& scheduling_task : scheduling_state.declined_tasks) {
        declined_array.append(SchedulingTaskToJsonValue(scheduling_task));
    }
    state_storage["flexible-tasks"] = flexible_array;
    state_storage["allocated-tasks"] = allocated_array;
    state_storage["declined-tasks"] = declined_array;
    Json::Value machine_keys(Json::arrayValue);
    Json::Value machine_dict;
    for (const auto& [key, value] : scheduling_state.machine_availability) {
        machine_dict[key] = value;
        machine_keys.append(key);
    }
    state_storage["machine-availability"] = machine_dict;
    state_storage["machine-keys"] = machine_keys;
    Json::Value allocation_2d_array(Json::arrayValue);
    for (const auto& interval_vector: scheduling_state.task_allocation) {
        Json::Value interval_1d_array(Json::arrayValue);
        for (const auto& interval_item: interval_vector) {
            interval_1d_array.append(IntervalToJsonValue(interval_item));
        }
        allocation_2d_array.append(interval_1d_array);
    }
    state_storage["task-allocation"] = allocation_2d_array;
    Json::Value request_history_2d_array(Json::arrayValue);
    for (const auto& task_vector: scheduling_state.request_history) {
        Json::Value task_array_1d(Json::arrayValue);
        for (const auto& task_item: task_vector) {
            task_array_1d.append(SchedulingTaskToJsonValue(task_item));
        }
        request_history_2d_array.append(task_array_1d);
    }
    state_storage["request-history"] = request_history_2d_array;
    Json::Value price_history_array(Json::arrayValue);
    for (const auto& price : scheduling_state.price_history) {
        price_history_array.append(price);
    }
    state_storage["price-history"] = price_history_array;
    Json::Value period_history_array(Json::arrayValue);
    for (const auto& period: scheduling_state.period_history) {
        period_history_array.append(period);
    }
    state_storage["period-history"] = period_history_array;
    return state_storage;
}

SchedulingState JsonValueToSchedulingState(const Json::Value& state_storage) {
    SchedulingState scheduling_state;
    scheduling_state.state_time = state_storage["state-time"].asDouble();
    scheduling_state.allocated_revenue = state_storage["allocated-revenue"].asDouble();
    scheduling_state.state_period = state_storage["state-period"].asUInt();
    for (const auto& task_storage : state_storage["flexible-tasks"]) {
        scheduling_state.flexible_tasks.push_back(JsonValueToSchedulingTask(task_storage));
    }
    for (const auto& task_storage : state_storage["allocated-tasks"]) {
        scheduling_state.allocated_tasks.push_back(JsonValueToSchedulingTask(task_storage));
    }
    for (const auto& task_storage : state_storage["declined-tasks"]) {
        scheduling_state.declined_tasks.push_back(JsonValueToSchedulingTask(task_storage));
    }
    std::vector<unsigned> machine_keys;
    for (const auto& key_storage: state_storage["machine-keys"]) {
        machine_keys.push_back(key_storage.asUInt());
    }
    for (unsigned key: machine_keys) {
        scheduling_state.machine_availability[key] = state_storage[
            "machine-availability"][key].asDouble();
    }
    for (const auto& array_1d : state_storage["task-allocation"]) {
        std::vector<Interval> interval_vector;
        for (const auto& value_storage : array_1d) {
            interval_vector.push_back(JsonValueToInterval(value_storage));
        }
        scheduling_state.task_allocation.push_back(interval_vector);
    }
    for (const auto& array_1d: state_storage["request-history"]) {
        std::vector<SchedulingTask> task_vector;
        for (const auto& value_storage: array_1d) {
            task_vector.push_back(JsonValueToSchedulingTask(value_storage));
        }
        scheduling_state.request_history.push_back(task_vector);
    }
    for (const auto& price_storage : state_storage["price-history"]) {
        scheduling_state.price_history.push_back(price_storage.asDouble());
    }
    for (const auto& period_storage: state_storage["period-history"]) {
        scheduling_state.period_history.push_back(period_storage.asUInt());
    }
    return scheduling_state;
}


} // namespace accurate
