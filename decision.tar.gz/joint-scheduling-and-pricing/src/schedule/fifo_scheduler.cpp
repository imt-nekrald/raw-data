#include <cassert>
#include <vector>
#include <algorithm>

#include "../schedule/fifo_scheduler.h"
#include "../schedule/scheduling_state.h"
#include "../data/setting.h"


namespace accurate {

OnlineFIFOScheduler::OnlineFIFOScheduler(const Setting& setting) : kSetting(setting) {
    ResetState();
};

void OnlineFIFOScheduler::UpdateSchedule(
        unsigned period, const std::vector<SchedulingTask>& arriving_tasks) {
    assert(state_.state_period == period);
    if (arriving_tasks.size()) {
        state_.request_history.push_back(arriving_tasks);
        double price_per_task = arriving_tasks[0].price;
        for ([[maybe_unused]] const SchedulingTask& task : arriving_tasks) {
            assert(task.price == price_per_task);
        }
        state_.price_history.push_back(price_per_task);
        state_.period_history.push_back(period);
    }
    double time_period_begins = state_.state_time;
    double time_period_over = time_period_begins + kSetting.period_durations[period];
    for (const auto& task : arriving_tasks) {
        unsigned machine_to_load = 0;
        for (unsigned idx_machine: task.compatible_machines)  {
            if (state_.machine_availability[idx_machine]
                    < state_.machine_availability[machine_to_load]) {
                machine_to_load = idx_machine;
            }
        }
        double start_time = std::max({task.availability_time,
            state_.machine_availability[machine_to_load], time_period_begins});
        double completion_time = start_time + task.duration_per_machine[machine_to_load]
            + task.delivery_per_machine[machine_to_load];
        double delay_penalty = 0;
        if (completion_time > task.due_time) {
            delay_penalty = task.delay_cost * (completion_time - task.due_time);
        }
        if (delay_penalty > task.decline_cost) {
            state_.declined_tasks.push_back(task);
            state_.allocated_revenue += (task.price - task.decline_cost);
        } else {
            Interval interval = {
                task, start_time, completion_time, delay_penalty, machine_to_load };
            state_.task_allocation[machine_to_load].push_back(interval);
            state_.allocated_tasks.push_back(task);
            state_.allocated_revenue += (task.price - delay_penalty);
            state_.machine_availability[machine_to_load] = interval.completion_time;
        }
    }
    state_.state_period = period + 1;
    state_.state_time = time_period_over;
};

const SchedulingState& OnlineFIFOScheduler::GetState() const {
    return state_;
};

void OnlineFIFOScheduler::SetState(const SchedulingState& state) {
    state_ = state;
};

void OnlineFIFOScheduler::FinalizeSchedule() {
};

SchedulingPlan OnlineFIFOScheduler::PrepareSchedulingPlan() const {
    SchedulingPlan plan = {
        state_.task_allocation, state_.declined_tasks, state_.allocated_revenue};
    return plan;
};

void OnlineFIFOScheduler::ResetState() {
    state_ = SchedulingState();
    state_.task_allocation.resize(kSetting.n_machines);
    for (unsigned idx_machine = 0; idx_machine < kSetting.n_machines; ++idx_machine) {
        state_.machine_availability[idx_machine] = 0.;
    }
};

} // namespace accurate

