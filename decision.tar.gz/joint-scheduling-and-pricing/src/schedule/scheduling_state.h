#pragma once

#include <json/value.h>
#include <vector>
#include <map>
#include <json/json.h>

#include "../schedule/scheduling_task.h"


namespace accurate {


struct Interval {
    SchedulingTask task;
    double start_time = 0.;
    double completion_time = 0.;
    double delay_penalty = 0.;
    unsigned machine_id = 0;
};

Json::Value IntervalToJsonValue(const Interval& interval);
Interval JsonValueToInterval(const Json::Value& json_interval);


struct SchedulingState {
    double state_time = 0.;
    double allocated_revenue = 0.;
    unsigned state_period = 0;
    std::vector<SchedulingTask> flexible_tasks;
    std::vector<SchedulingTask> allocated_tasks;
    std::vector<SchedulingTask> declined_tasks;
    std::map<unsigned, double> machine_availability;
    std::vector<std::vector<Interval>> task_allocation;
    std::vector<std::vector<SchedulingTask>> request_history;
    std::vector<double> price_history;
    std::vector<unsigned> period_history;
};

Json::Value SchedulingStateToJsonValue(
        const SchedulingState& scheduling_state);
SchedulingState JsonValueToSchedulingState(
        const Json::Value& state_storage);


} // namespace accurate

