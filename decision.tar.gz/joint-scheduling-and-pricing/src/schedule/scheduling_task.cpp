#include <vector>

#include <boost/uuid/uuid.hpp>
#include <boost/uuid/uuid_generators.hpp>
#include <boost/uuid/uuid_io.hpp>
#include <boost/lexical_cast.hpp>

#include "../data/setting.h"
#include "../schedule/scheduling_task.h"


namespace accurate {

std::string GenerateUUID() {
	boost::uuids::random_generator generator;
	return boost::lexical_cast<std::string>(generator());
};

std::vector<SchedulingTask> BuildTasksFromOrder(
		const OrderType& order_type, double price_per_task, double request_time) {
    SchedulingTask model_task;
    model_task.availability_time = request_time + order_type.availability_time;
    model_task.wait_time_after_order = order_type.availability_time;
    model_task.due_time = request_time + order_type.due_time;
    model_task.price = price_per_task;
    model_task.compatible_machines = order_type.compatible_machines;
    model_task.duration_per_machine = order_type.duration_per_machine;
    model_task.delivery_per_machine = order_type.delivery_per_machine;
    model_task.decline_cost = order_type.decline_cost;
    model_task.delay_cost = order_type.delay_cost;
    std::vector<SchedulingTask> order_tasks;
    for (unsigned idx_task = 0; idx_task < order_type.count; ++idx_task) {
        SchedulingTask task = model_task;
        task.uuid = GenerateUUID();
        order_tasks.push_back(task);
    }
    return order_tasks;
};

SchedulingTask JsonValueToSchedulingTask(const Json::Value& json_task) {
    SchedulingTask scheduling_task;
    scheduling_task.uuid = json_task["uuid"].asString();
    scheduling_task.price = json_task["price"].asDouble();
    scheduling_task.delay_cost = json_task["delay-cost"].asDouble();
    scheduling_task.decline_cost = json_task["decline-cost"].asDouble();
    for (const auto& duration_value : json_task["duration-per-machine"]) {
        scheduling_task.duration_per_machine.push_back(duration_value.asDouble());
    }
    for (const auto& delivery_value : json_task["delivery-per-machine"]) {
        scheduling_task.delivery_per_machine.push_back(delivery_value.asDouble());
    }
    for (const auto& compatible_id : json_task["compatible-machines"]) {
        scheduling_task.compatible_machines.push_back(compatible_id.asUInt());
    }
    scheduling_task.availability_time = json_task["release-time"].asDouble();
    scheduling_task.wait_time_after_order = json_task["release-term"].asDouble();
    scheduling_task.due_time = json_task["due-time"].asDouble();
    return scheduling_task;
};

Json::Value SchedulingTaskToJsonValue(const SchedulingTask& scheduling_task) {
    Json::Value storage;
    storage["uuid"] = scheduling_task.uuid;
    storage["price"] = scheduling_task.price;
    storage["delay-cost"] = scheduling_task.delay_cost;
    Json::Value duration_json(Json::arrayValue);
    for (const double& duration : scheduling_task.duration_per_machine) {
        duration_json.append(duration);
    }

    storage["duration-per-machine"] = duration_json;
    Json::Value delivery_json(Json::arrayValue);
    for (const double& delivery : scheduling_task.delivery_per_machine) {
        delivery_json.append(delivery);
    }
    storage["delivery-per-machine"] = delivery_json;
    Json::Value machines_json(Json::arrayValue);
    for (const unsigned& idx_machine : scheduling_task.compatible_machines) {
        machines_json.append(idx_machine);
    }
    storage["compatible-machines"] = machines_json;
    storage["release-time"] = scheduling_task.availability_time;
    storage["release-term"] = scheduling_task.wait_time_after_order;
    storage["due-time"] = scheduling_task.due_time;
    return storage;
};

} // namespace accurate
