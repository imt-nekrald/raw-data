#pragma once

#include <vector>

#include "../schedule/scheduling_state.h"

namespace accurate {

struct SchedulingPlan {
    std::vector<std::vector<Interval>> task_allocation;
    std::vector<SchedulingTask> declined_tasks;
    double scheduling_cost = 0.;
};

class IOnlineScheduler {
public:
    IOnlineScheduler() {};
    virtual void UpdateSchedule(
            unsigned period, const std::vector<SchedulingTask>& arriving_tasks) = 0;
    virtual const SchedulingState& GetState() const = 0;
    virtual void SetState(const SchedulingState& state) = 0;
    virtual void FinalizeSchedule() = 0;
    virtual SchedulingPlan PrepareSchedulingPlan() const = 0;
    virtual void ResetState() = 0;
    virtual ~IOnlineScheduler() {};
};

} // namespace accurate

