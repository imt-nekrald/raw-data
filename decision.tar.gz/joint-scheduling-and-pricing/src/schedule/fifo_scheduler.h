#pragma once

#include <vector>

#include "../schedule/scheduling_state.h"
#include "../schedule/scheduler_interface.h"


namespace accurate {

class OnlineFIFOScheduler : public IOnlineScheduler {
public:
    OnlineFIFOScheduler(const Setting& setting);
    virtual void UpdateSchedule(
            unsigned period, const std::vector<SchedulingTask>& arriving_tasks) final override;
    virtual const SchedulingState& GetState() const final override;
    virtual void SetState(const SchedulingState& state) final override;
    virtual void FinalizeSchedule() final override;
    virtual SchedulingPlan PrepareSchedulingPlan() const final override;
    virtual void ResetState() final override;
    virtual ~OnlineFIFOScheduler() {};

private:
    SchedulingState state_;
    const Setting& kSetting;
};

} // namespace accurate

