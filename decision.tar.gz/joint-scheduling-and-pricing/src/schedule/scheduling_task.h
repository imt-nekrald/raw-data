#pragma once

#include <vector>

#include "../data/setting.h"


namespace accurate {


struct SchedulingTask {
    std::string uuid;
    double price = 0.;
    double delay_cost = 0.;
    double decline_cost = 0.;
    std::vector<double> duration_per_machine;
    std::vector<double> delivery_per_machine;
    std::vector<unsigned> compatible_machines;
    double availability_time = 0.;
    double wait_time_after_order = 0.;
    double due_time = 0.;
};


SchedulingTask JsonValueToSchedulingTask(const Json::Value& json_task);
Json::Value SchedulingTaskToJsonValue(const SchedulingTask& scheduling_task);

std::string GenerateUUID();
std::vector<SchedulingTask> BuildTasksFromOrder(
        const OrderType& order_type, double price_per_task, double request_time);


} // namespace accurate
