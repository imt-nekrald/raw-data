#pragma once

#include <vector>
#include <string>

namespace research {


struct OptionsParsed {
    std::vector<std::string> calls_requested;
    std::vector<std::string> approaches_requested;
    std::vector<std::string> instances_requested;
    std::string report_path = "evaluation.json";
    unsigned n_genetic_iterations = 100;
    int seed = 18;
};

#ifdef RESEARCH_MODE
int main(int argc, char** argv);
#endif

} // namespace research


