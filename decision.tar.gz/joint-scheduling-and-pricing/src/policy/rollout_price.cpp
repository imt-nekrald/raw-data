#include <memory>
#include <vector>
#include <limits>
#include <cassert>
#include <boost/log/trivial.hpp>

#include "../schedule/scheduling_state.h"
#include "../schedule/scheduling_task.h"
#include "../schedule/scheduler_interface.h"
#include "../schedule/fifo_scheduler.h"
#include "../policy/price_interface.h"
#include "../policy/rollout_price.h"
#include "../evaluate/scorer.h"
#include "../evaluate/trajectory_manager.h"


namespace accurate {

ExtendingRolloutPricePolicy::ExtendingRolloutPricePolicy(
        std::shared_ptr<IPolicy> estimating_policy,
        const Setting& setting,
        unsigned sample_count)
        : AbstractPolicy(setting)
        , estimating_policy_(estimating_policy)
        , kSampleCount(sample_count) {
}

double ExtendingRolloutPricePolicy::SuggestPrice(
        unsigned period, const OrderType& order) const {
    std::shared_ptr<IPolicy> policy = estimating_policy_;
    unsigned order_type = order.idx_type;
    std::vector<double> possible_prices = kSetting.price_ranges[period][order_type];
        std::shared_ptr<Sampler> sampler = std::make_shared<Sampler>(kSetting);
    std::vector<Trajectory> lookahead_trajectories;
    for (unsigned idx_sample = 0; idx_sample < kSampleCount; ++idx_sample) {
        Trajectory entry = sampler->PrepareSample();
        lookahead_trajectories.push_back(entry);
    }
    SchedulingState policy_state = policy->GetSchedulingState();
    double accumulated_time = policy_state.state_time;
    double best_score = -std::numeric_limits<double>::max();
    double best_price = *std::max_element(possible_prices.begin(), possible_prices.end());
    assert(period == policy_state.state_period);
    for (double proposed_price : possible_prices) {
        double total_score = 0;
        for (unsigned idx_sample = 0; idx_sample < kSampleCount; ++idx_sample) {
            Trajectory trajectory = lookahead_trajectories[idx_sample];
            SchedulingState local_state = policy_state;
            unsigned idx_period = local_state.state_period;
            double willingness_to_pay = trajectory.willingness_to_pay.at(idx_period);
            unsigned next_period = idx_period + 1;
            policy->SetSchedulingState(local_state);
            std::vector<SchedulingTask> order_tasks;
            if (trajectory.sampled_orders.find(idx_period) != trajectory.sampled_orders.end()) {
                OrderType order = trajectory.sampled_orders.at(idx_period);
                if (proposed_price < willingness_to_pay) {
                    order_tasks = BuildTasksFromOrder(order, proposed_price, accumulated_time);
                }
            }
            policy->UpdateSchedule(idx_period, order_tasks);
            std::shared_ptr<IOnlineScheduler> scheduler
                = std::make_shared<OnlineFIFOScheduler>(kSetting);
            std::vector<Trajectory> vector_with_trajectory = { trajectory };
            std::shared_ptr<ITrajectoryManager> trajectory_manager
                = std::make_shared<StaticTrajectoryManager>(kSetting, vector_with_trajectory);
            std::shared_ptr<IPolicyScorer> policy_scorer
                = std::make_shared<SamplingScorer>(kSetting, trajectory_manager);

            double prefix_score = policy->GetSchedulingState().allocated_revenue;
            total_score += policy_scorer->GetScore(
                    next_period, prefix_score, policy).revenue_.average_;
        }
        double average_score = total_score / kSampleCount;
        if (average_score > best_score) {
            best_score = average_score;
            best_price = proposed_price;
        }
    }
    policy->SetSchedulingState(policy_state);
    return best_price;
}

void ExtendingRolloutPricePolicy::UpdateSchedule(
        unsigned period, const std::vector<SchedulingTask>& arriving_tasks) {
    estimating_policy_->UpdateSchedule(period, arriving_tasks);
};

const SchedulingState& ExtendingRolloutPricePolicy::GetSchedulingState() const {
    return estimating_policy_->GetSchedulingState();
};

void ExtendingRolloutPricePolicy::SetSchedulingState(const SchedulingState& state) {
    return estimating_policy_->SetSchedulingState(state);
};

void ExtendingRolloutPricePolicy::FinalizeSchedule() {
    estimating_policy_->FinalizeSchedule();
};

SchedulingPlan ExtendingRolloutPricePolicy::ProvideSchedulingPlan() const {
    return estimating_policy_->ProvideSchedulingPlan();
};


} // namespace accurate
