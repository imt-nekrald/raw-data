#include <vector>
#include <memory>
#include <cassert>
#include <random>
#include <algorithm>
#include <json/json.h>

#include "../data/setting.h"
#include "../policy/price_interface.h"
#include "../policy/static_price.h"
#include "../schedule/scheduler_interface.h"
#include "../schedule/scheduling_state.h"
#include "../schedule/scheduling_task.h"


namespace accurate {


Json::Value StaticPriceListToJsonValue(const StaticPriceList& price_list) {
    Json::Value price_storage;
    Json::Value price_matrix(Json::arrayValue);
    for (const auto& row: price_list.prices) {
        Json::Value price_vector(Json::arrayValue);
        for (const auto& element : row) {
            price_vector.append(element);
        }
        price_matrix.append(price_vector);
    }
    price_storage["prices"] = price_matrix;
    return price_storage;
}


StaticPriceList JsonValueToStaticPriceList(const Json::Value& price_storage) {
    StaticPriceList price_list;
    const Json::Value price_matrix = price_storage["prices"];
    for (const auto& price_vector : price_matrix) {
        std::vector<double> row_prices;
        for (const auto& price_entry : price_vector) {
            row_prices.push_back(price_entry.asDouble());
        }
        price_list.prices.push_back(row_prices);
    }
    return price_list;
}


StaticPriceList PriceToMinimal(const Setting& setting) {
    StaticPriceList price_list;
    price_list.prices.resize(setting.n_periods);
    for (unsigned idx_period = 0; idx_period < setting.n_periods; ++idx_period) {
        price_list.prices[idx_period].resize(setting.n_order_types);
        for (unsigned idx_order = 0; idx_order < setting.n_order_types; ++idx_order) {
            price_list.prices[idx_period][idx_order] = *std::min_element(
                setting.price_ranges[idx_period][idx_order].begin(),
                setting.price_ranges[idx_period][idx_order].end()
            );
        }
    }
    return price_list;
}


StaticPriceList PriceToMaximal(const Setting& setting) {
    StaticPriceList price_list;
    price_list.prices.resize(setting.n_periods);
    for (unsigned idx_period = 0; idx_period < setting.n_periods; ++idx_period) {
        price_list.prices[idx_period].resize(setting.n_order_types);
        for (unsigned idx_order = 0; idx_order < setting.n_order_types; ++idx_order) {
            price_list.prices[idx_period][idx_order] = *std::max_element(
                setting.price_ranges[idx_period][idx_order].begin(),
                setting.price_ranges[idx_period][idx_order].end()
            );
        }
    }
    return price_list;
}


StaticPriceList PriceMinMaxRandomization(
        const Setting& setting, double min_proba, unsigned random_seed) {
    std::default_random_engine generator;
    generator.seed(random_seed);
    StaticPriceList price_list;
    price_list.prices.resize(setting.n_periods);
    std::uniform_real_distribution<double> distribution(0., 1.);
    for (unsigned idx_period = 0; idx_period < setting.n_periods; ++idx_period) {
        price_list.prices[idx_period].resize(setting.n_order_types);
        for (unsigned idx_order = 0; idx_order < setting.n_order_types; ++idx_order) {
            if (distribution(generator) < min_proba) {
                price_list.prices[idx_period][idx_order] = *std::min_element(
                    setting.price_ranges[idx_period][idx_order].begin(),
                    setting.price_ranges[idx_period][idx_order].end()
                );
            } else {
                price_list.prices[idx_period][idx_order] = *std::max_element(
                    setting.price_ranges[idx_period][idx_order].begin(),
                    setting.price_ranges[idx_period][idx_order].end()
                );
            }
        }
    }
    return price_list;
}


StaticPricePolicy::StaticPricePolicy(
        const StaticPriceList& static_prices,
        const Setting& setting,
        std::shared_ptr<IOnlineScheduler> online_scheduler)
        : AbstractPolicy(setting)
        , kStaticPrices(static_prices)
        , scheduler_(online_scheduler) {
};


double StaticPricePolicy::SuggestPrice(
        unsigned period, const OrderType& order) const {
    assert(period == scheduler_->GetState().state_period);
    assert(period < kSetting.n_periods);
    assert(kStaticPrices.prices.size() == kSetting.n_periods);
    return kStaticPrices.prices[period][order.idx_type];
};


void StaticPricePolicy::UpdateSchedule(
        unsigned period, const std::vector<SchedulingTask>& arriving_tasks) {
    scheduler_->UpdateSchedule(period, arriving_tasks);
};


const SchedulingState& StaticPricePolicy::GetSchedulingState() const {
    return scheduler_->GetState();
};


void StaticPricePolicy::SetSchedulingState(const SchedulingState& state) {
    return scheduler_->SetState(state);
};


void StaticPricePolicy::FinalizeSchedule() {
    scheduler_->FinalizeSchedule();
};


SchedulingPlan StaticPricePolicy::ProvideSchedulingPlan() const {
    return scheduler_->PrepareSchedulingPlan();
};


} // namespace accurate

