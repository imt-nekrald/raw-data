#pragma once

#include <vector>

#include "../data/setting.h"
#include "../schedule/scheduling_state.h"
#include "../schedule/scheduling_task.h"
#include "../schedule/scheduler_interface.h"


namespace accurate {

class IPolicy {
public:
    virtual double SuggestPrice(unsigned period, const OrderType& order) const = 0;
    virtual void UpdateSchedule(
            unsigned period, const std::vector<SchedulingTask>& arriving_tasks) = 0;
    virtual const SchedulingState& GetSchedulingState() const = 0;
    virtual void SetSchedulingState(const SchedulingState& state) = 0;
    virtual SchedulingPlan ProvideSchedulingPlan() const = 0;
    virtual void FinalizeSchedule() = 0;
    virtual ~IPolicy() {};
};

class AbstractPolicy : public IPolicy {
public:
    AbstractPolicy(const Setting& setting) : kSetting(setting) {};
    virtual double SuggestPrice(unsigned period, const OrderType& order) const override = 0;
    virtual void UpdateSchedule(
            unsigned period, const std::vector<SchedulingTask>& arriving_tasks) override = 0;
    virtual const SchedulingState& GetSchedulingState() const override = 0;
    virtual void SetSchedulingState(const SchedulingState& state) override = 0;
    virtual SchedulingPlan ProvideSchedulingPlan() const override = 0;
    virtual void FinalizeSchedule() override =0;
    virtual ~AbstractPolicy() {};

protected:
    const Setting& kSetting;

};



} // namespace accurate
