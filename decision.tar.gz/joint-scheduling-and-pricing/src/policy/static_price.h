#pragma once

#include <vector>
#include <memory>
#include <json/json.h>

#include "../data/setting.h"
#include "../policy/price_interface.h"
#include "../schedule/scheduler_interface.h"
#include "../schedule/scheduling_state.h"
#include "../schedule/scheduling_task.h"


namespace accurate {

struct StaticPriceList {
    std::vector<std::vector<double>> prices; // Time Horizon x Order Types
};

Json::Value StaticPriceListToJsonValue(
        const StaticPriceList& price_list);
StaticPriceList JsonValueToStaticPriceList(
        const Json::Value& price_storage);


StaticPriceList PriceToMinimal(const Setting& setting);
StaticPriceList PriceToMaximal(const Setting& setting);
StaticPriceList PriceMinMaxRandomization(
        const Setting& setting, double min_proba, unsigned random_seed);


class StaticPricePolicy : public AbstractPolicy {
public:
    explicit StaticPricePolicy(
            const StaticPriceList& static_prices,
            const Setting& setting,
            std::shared_ptr<IOnlineScheduler> scheduler);
    virtual double SuggestPrice(
            unsigned period,
            const OrderType& order) const override final;
    virtual void UpdateSchedule(
            unsigned period,
            const std::vector<SchedulingTask>& arriving_tasks) override final;
    virtual const SchedulingState& GetSchedulingState() const override final;
    virtual void SetSchedulingState(const SchedulingState& state) override final;
    virtual SchedulingPlan ProvideSchedulingPlan() const override final;
    virtual void FinalizeSchedule() override final;
    virtual ~StaticPricePolicy() {};

private:
    const StaticPriceList kStaticPrices;
    std::shared_ptr<IOnlineScheduler> scheduler_;
};

} // namespace accurate

