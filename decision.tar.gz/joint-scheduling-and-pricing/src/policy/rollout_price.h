#pragma once

#include <vector>
#include <memory>

#include "../data/setting.h"
#include "../policy/price_interface.h"
#include "../schedule/scheduler_interface.h"
#include "../schedule/scheduling_state.h"

namespace accurate {

class ExtendingRolloutPricePolicy : public AbstractPolicy {
public:
    explicit ExtendingRolloutPricePolicy(
            std::shared_ptr<IPolicy> estimating_policy,
            const Setting& setting,
            unsigned sample_count);
    virtual double SuggestPrice(
            unsigned period,
            const OrderType& order) const override final;
    virtual void UpdateSchedule(
            unsigned period,
            const std::vector<SchedulingTask>& arriving_tasks) override final;
    virtual const SchedulingState& GetSchedulingState() const override final;
    virtual void SetSchedulingState(
            const SchedulingState& state) override final;
    virtual SchedulingPlan ProvideSchedulingPlan() const override final;
    virtual void FinalizeSchedule() override final;
    virtual ~ExtendingRolloutPricePolicy() {};

private:
    std::shared_ptr<IPolicy> estimating_policy_;
    const unsigned kSampleCount;
};

} // namespace accurate
