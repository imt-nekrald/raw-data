#pragma once

#include <random>

#include "../data/setting.h"
#include "../data/trajectory.h"

namespace accurate {

class Sampler {
public:
    Sampler(const Setting& setting);
    Trajectory PrepareSample();

private:
    std::mt19937 generator_;
    const Setting kSetting;
};

} // namespace accurate
