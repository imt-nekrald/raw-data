#pragma once

#include <map>

#include "../data/setting.h"

namespace accurate {

struct Trajectory {
    std::map<unsigned, OrderType> sampled_orders;
    std::map<unsigned, double> willingness_to_pay;
};

} //namespace accurate
