#pragma once

#include <vector>
#include <string>
#include <map>
#include <utility>
#include <json/json.h>


namespace accurate {


struct OrderType {
    std::string name = "";
    unsigned idx_type = 0;
    unsigned count = 0;
    double linear_sensitivity = 0.;
    double availability_time = 0.;
    double due_time = 0.;
    double delay_cost = 0.;
    double decline_cost = 0.;
    std::vector<unsigned> compatible_machines;
    std::vector<double> duration_per_machine;
    std::vector<double> delivery_per_machine;
};


Json::Value OrderTypeToJsonValue(const OrderType& order_type);
OrderType JsonValueToOrderType(const Json::Value& order_storage);


struct Setting {
    unsigned n_periods = 0;
    unsigned n_order_types = 0;
    unsigned n_machines = 0;
    std::vector<OrderType> order_types;
    std::vector<std::vector<double>> period_order_probability; // n_periods x n_order_types
    std::vector<std::vector<std::vector<double>>> price_ranges; // n_periods x n_order_types x n_prices
    std::vector<double> period_durations; // n_periods
};


Json::Value SettingToJsonValue(const Setting& setting);
Setting JsonValueToSetting(const Json::Value& setting_storage);


enum class InstanceType {
    MINIMAL_SINGLE_MACHINE,
    SMALL_SINGLE_MACHINE,
    MEDIUM_TWO_MACHINES,
    CUSTOM_JSON_BASED
};


Setting BuildSettingInstance(const InstanceType& instance);


class InstanceTypeNameConverter {
public:
    InstanceTypeNameConverter() {
        type_to_name_[InstanceType::MINIMAL_SINGLE_MACHINE] = "minimal";
        type_to_name_[InstanceType::SMALL_SINGLE_MACHINE] = "small";
        type_to_name_[InstanceType::MEDIUM_TWO_MACHINES] = "medium";
        type_to_name_[InstanceType::CUSTOM_JSON_BASED] = "custom-json-based";
        for (const auto& pair : type_to_name_) {
            name_to_type_[pair.second] = pair.first;
        }
    }
    InstanceType NameToType(const std::string& name) const {
        return name_to_type_.at(name);
    }
    std::string TypeToName(const InstanceType& type) const {
        return type_to_name_.at(type);
    }
    std::vector<std::string> RetrieveAllInstanceNames() const {
        std::vector<std::string > instance_names;
        for (const auto& [type, name]: type_to_name_) {
            instance_names.push_back(name);
        }
        return instance_names;
    }
    std::vector<InstanceType> RetrieveAllInstanceTypes() const {
        std::vector<InstanceType> instance_types;
        for (const auto& [type, name] : type_to_name_) {
            instance_types.push_back(type);
        }
        return instance_types;
    }
    std::string DescribeAllInstanceNames() const {
        std::vector<std::string> instance_names = RetrieveAllInstanceNames();
        std::string description = "";
        for (const std::string& name : instance_names) {
            description = name + " " + description;
        }
        return description;
    }
private:
    std::map<InstanceType, std::string> type_to_name_;
    std::map<std::string, InstanceType> name_to_type_;
};


} // namespace accurate

