#include <random>

#include "../data/setting.h"
#include "../data/sampler.h"

namespace accurate {

Sampler::Sampler(const Setting& setting) : kSetting(setting) {
    unsigned random_seed = 3;
    generator_.seed(random_seed);
}

Trajectory Sampler::PrepareSample() {
    Trajectory sample;
    for (unsigned idx_period = 0; idx_period < kSetting.n_periods; ++idx_period) {
        std::vector<double> probabilities = kSetting.period_order_probability[idx_period];

        std::discrete_distribution<> discrete_distribution(probabilities.begin(), probabilities.end());
        unsigned idx_order = discrete_distribution(generator_);

        const OrderType& order = kSetting.order_types[idx_order];
        double range_lhs = 0.;
        double range_rhs = 1. / order .linear_sensitivity;

        std::uniform_real_distribution<double> uniform_distribution(range_lhs, range_rhs);
        double threshold_amount = uniform_distribution(generator_);

        sample.sampled_orders[idx_period] = order;
        sample.willingness_to_pay[idx_period] = threshold_amount;
    }
    return sample;
}

} // namespace accurate
