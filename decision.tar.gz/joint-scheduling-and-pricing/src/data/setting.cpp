#include <random>
#include <vector>
#include <stdexcept>
#include <string>

#include "../data/setting.h"


namespace accurate {


Setting BuildMinimalSingleMachineSetting(unsigned random_seed) {
    Setting setting;
    std::default_random_engine generator;
    generator.seed(random_seed);
    std::uniform_real_distribution<double> period_distribution(12., 24.);
    setting.n_machines = 1;
    setting.n_order_types = 1;

    OrderType small;
    small.name = "Minimal Unique";
    small.idx_type = 0;
    small.linear_sensitivity = 1. / 25.;
    small.count = 10;
    small.availability_time = 12.;
    small.due_time = 24.;
    small.delay_cost =  0.25;
    small.decline_cost = 50.;
    small.compatible_machines = { 0 };
    small.duration_per_machine = { 0.25 };
    small.delivery_per_machine = { 3. };

    setting.order_types = { small };
    std::vector<double> type_probabilities = { 1.0 };
    std::vector<std::vector<double>> price_ranges = { {5., 10., 15., 20. ,25.} };

    setting.n_periods = 10;
    setting.period_durations.resize(setting.n_periods);
    setting.price_ranges.resize(setting.n_periods);
    setting.period_order_probability.resize(setting.n_periods);
    for (unsigned idx_period = 0; idx_period < setting.n_periods; ++idx_period) {
        setting.period_durations[idx_period] = period_distribution(generator);
        setting.period_order_probability[idx_period] = type_probabilities;
        setting.price_ranges[idx_period] = price_ranges;
    }
    return setting;
}


Setting BuildSmallSingleMachineSetting(unsigned random_seed) {
    Setting setting;
    std::default_random_engine generator;
    generator.seed(random_seed);
    std::uniform_real_distribution<double> period_distribution(12., 24.);

    setting.n_machines = 1;
    setting.n_order_types = 2;

    OrderType small;
    small.name = "Small Easy";
    small.idx_type = 0;
    small.linear_sensitivity = 1. / 25.;
    small.count = 50;
    small.availability_time = 18.;
    small.due_time = 48.;
    small.delay_cost = 0.25;
    small.decline_cost = 100.;
    small.compatible_machines = { 0 };
    small.duration_per_machine = { 0.25 };
    small.delivery_per_machine = { 1. };

    OrderType large;
    large.name = "Small Complex";
    large.idx_type = 1;
    large.linear_sensitivity = 1. / 75.;
    large.count = 30;
    large.availability_time = 12.;
    large.due_time = 72.;
    large.delay_cost = 0.75;
    large.decline_cost = 300;
    large.compatible_machines = { 0 };
    large.duration_per_machine = { 1.5 };
    large.delivery_per_machine = { 1. };

    setting.order_types = { small, large };
    std::vector<double> type_probabilities = { 0.8, 0.2 };
    std::vector<std::vector<double>> price_ranges = {
        {5., 15. ,25.}, {25., 50., 75.}
    };

    setting.n_periods = 20;
    setting.period_durations.resize(setting.n_periods);
    setting.price_ranges.resize(setting.n_periods);
    setting.period_order_probability.resize(setting.n_periods);
    for (unsigned idx_period = 0; idx_period < setting.n_periods; ++idx_period) {
        setting.period_durations[idx_period] = period_distribution(generator);
        setting.period_order_probability[idx_period] = type_probabilities;
        setting.price_ranges[idx_period] = price_ranges;
    }
    return setting;
}


Setting BuildMediumTwoMachinesSetting(unsigned random_seed) {
    Setting setting;
    std::default_random_engine generator;
    generator.seed(random_seed);
    std::uniform_real_distribution<double> period_distribution(12., 24.);

    setting.n_machines = 2;
    setting.n_order_types = 2;

    OrderType small;
    small.idx_type = 0;
    small.name = "Medium Simple";
    small.linear_sensitivity = 1. / 25.;
    small.count = 50;
    small.availability_time = 18.;
    small.due_time = 48.;
    small.delay_cost = 0.25;
    small.decline_cost = 100.;
    small.compatible_machines = { 0, 1 };
    small.duration_per_machine = { 0.25, 0.5 };
    small.delivery_per_machine = { 1.0, 1.0 };

    OrderType large;
    large.name = "Medium Hard";
    large.idx_type = 1;
    large.linear_sensitivity = 1. / 75.;
    large.count = 30;
    large.availability_time = 12.;
    large.due_time = 72.;
    large.delay_cost = 0.75;
    large.decline_cost = 300;
    large.compatible_machines = { 0, 1 };
    large.duration_per_machine = { 1.5, 3.2 };
    large.delivery_per_machine = { 1.0, 1.0 };

    setting.order_types = { small, large };
    std::vector<double> type_probabilities = { 0.8, 0.2 };
    std::vector<std::vector<double>> price_ranges = { {5., 15. ,25.}, {25., 50., 75.} };

    setting.n_periods = 20;
    setting.period_durations.resize(setting.n_periods);
    setting.price_ranges.resize(setting.n_periods);
    setting.period_order_probability.resize(setting.n_periods);
    for (unsigned idx_period = 0; idx_period < setting.n_periods; ++idx_period) {
        setting.period_durations[idx_period] = period_distribution(generator);
        setting.period_order_probability[idx_period] = type_probabilities;
        setting.price_ranges[idx_period] = price_ranges;
    }

    return setting;
}

Setting BuildSettingInstance(const InstanceType& instance) {
    Setting setting;
    unsigned random_seed = 3;
    if (instance == InstanceType::MINIMAL_SINGLE_MACHINE) {
        setting = BuildMinimalSingleMachineSetting(random_seed);
    } else if (instance == InstanceType::SMALL_SINGLE_MACHINE) {
        setting = BuildSmallSingleMachineSetting(random_seed);
    } else if (instance == InstanceType::MEDIUM_TWO_MACHINES) {
        setting = BuildMediumTwoMachinesSetting(random_seed);
    } else {
        throw std::logic_error(std::string("Unexpected instance type!"));
    }
    return setting;
}


Json::Value OrderTypeToJsonValue(const OrderType& order_type) {
    Json::Value order_storage(Json::objectValue);
    order_storage["idx-type"] = order_type.idx_type;
    order_storage["count"] = order_type.count;
    order_storage["linear-sensitivity"] = order_type.linear_sensitivity;
    order_storage["release-term"] = order_type.availability_time;
    order_storage["due-term"] = order_type.due_time;
    order_storage["tardiness-penalty"] = order_type.delay_cost;
    order_storage["decline-penalty"] = order_type.decline_cost;
    order_storage["compatible-machines"] = Json::Value(Json::arrayValue);
    order_storage["duration-per-machine"] = Json::Value(Json::arrayValue);
    order_storage["delivery-per-machine"] = Json::Value(Json::arrayValue);
    order_storage["type-name"] = order_type.name.c_str();
    for (unsigned idx = 0; idx < order_type.compatible_machines.size(); ++idx) {
        order_storage["compatible-machines"].append(order_type.compatible_machines[idx]);
        order_storage["duration-per-machine"].append(order_type.duration_per_machine[idx]);
        order_storage["delivery-per-machine"].append(order_type.delivery_per_machine[idx]);
    }
    return order_storage;
};


OrderType JsonValueToOrderType(const Json::Value& order_storage) {
    OrderType order_type;
    order_type.idx_type = order_storage["idx-type"].asUInt();
    order_type.count = order_storage["count"].asUInt();
    order_type.linear_sensitivity = order_storage["linear-sensitivity"].asDouble();
    order_type.availability_time = order_storage["release-term"].asDouble();
    order_type.due_time = order_storage["due-term"].asDouble();
    order_type.delay_cost = order_storage["tardiness-penalty"].asDouble();
    order_type.decline_cost = order_storage["decline-penalty"].asDouble();
    order_type.name = order_storage["type-name"].asString();
    for (const auto& element : order_storage["compatible-machines"]) {
        order_type.compatible_machines.push_back(element.asUInt());
    }
    for (const auto& duration : order_storage["duration-per-machine"]) {
        order_type.duration_per_machine.push_back(duration.asDouble());
    }
    for (const auto& delivery : order_storage["delivery-per-machine"]) {
        order_type.delivery_per_machine.push_back(delivery.asDouble());
    }
    return order_type;
};


Json::Value SettingToJsonValue(const Setting& setting) {
    Json::Value setting_storage(Json::objectValue);
    setting_storage["n-periods"] = setting.n_periods;
    setting_storage["n-order-types"] = setting.n_order_types;
    setting_storage["n-machines"] = setting.n_machines;
    setting_storage["order-types"] = Json::Value(Json::arrayValue);
    for (const auto& order_type : setting.order_types) {
        setting_storage["order-types"].append(OrderTypeToJsonValue(order_type));
    }
    setting_storage["period-order-probability"] = Json::Value(Json::arrayValue);
    for (const auto& probability_descriptor : setting.period_order_probability) {
        Json::Value json_proba_array(Json::arrayValue);
        for (double probability : probability_descriptor) {
            json_proba_array.append(probability);
        }
        setting_storage["period-order-probability"].append(json_proba_array);
    }
    Json::Value periodic_array(Json::arrayValue);
    for (const auto& periodic_descriptor : setting.price_ranges) {
        Json::Value order_array(Json::arrayValue);
        for (const auto& order_descriptor : periodic_descriptor) {
            Json::Value price_array(Json::arrayValue);
            for (const auto& price : order_descriptor) {
                price_array.append(price);
            }
            order_array.append(price_array);
        }
        periodic_array.append(order_array);
    }
    setting_storage["price-ranges"] = periodic_array;
    Json::Value period_durations(Json::arrayValue);
    for (const double duration : setting.period_durations) {
        period_durations.append(duration);
    }
    setting_storage["period-durations"] = period_durations;
    return setting_storage;
};


Setting JsonValueToSetting(const Json::Value& setting_storage) {
    Setting setting;
    setting.n_periods = setting_storage["n-periods"].asUInt();
    setting.n_order_types = setting_storage["n-order-types"].asUInt();
    setting.n_machines = setting_storage["n-machines"].asUInt();

    for (const auto& order_type_json : setting_storage["order-types"]) {
        setting.order_types.push_back(JsonValueToOrderType(order_type_json));
    }

    std::vector<std::vector<double>> period_order_probability;
    for (const auto& period_component : setting_storage["period-order-probability"]) {
        std::vector<double> probabilities;
        for (const auto& order_component : period_component) {
            probabilities.push_back(order_component.asDouble());
        }
        period_order_probability.push_back(probabilities);
    }
    setting.period_order_probability = period_order_probability;

    std::vector<std::vector<std::vector<double>>> price_ranges;
    for (const auto& period_component : setting_storage["price-ranges"]) {
        std::vector<std::vector<double>> orders;
        for (const auto& order_component : period_component) {
            std::vector<double> prices;
            for (const auto& price_component : order_component) {
                prices.push_back(price_component.asDouble());
            }
            orders.push_back(prices);
        }
        price_ranges.push_back(orders);
    }
    setting.price_ranges = price_ranges;

    std::vector<double> period_durations;
    for (const auto& period_component : setting_storage["period-durations"]) {
        period_durations.push_back(period_component.asDouble());
    }
    setting.period_durations = period_durations;
    return setting;
};


} // namespace accurate
