#include <vector>
#include <utility>
#include <random>
#include <cassert>
#include <algorithm>
#include <memory>
#include <iostream>
#include <boost/log/trivial.hpp>

#include "../data/setting.h"
#include "../data/sampler.h"
#include "../evaluate/scorer.h"
#include "../policy/price_interface.h"
#include "../policy/static_price.h"
#include "../schedule/scheduler_interface.h"
#include "../schedule/fifo_scheduler.h"
#include "../search/genetic.h"


namespace accurate {


Json::Value GeneticConfigToJsonValue(const GeneticConfig& genetic_config) {
    Json::Value genetic_storage;
    genetic_storage["n-genetic-iterations"] = genetic_config.n_genetic_iterations;
    genetic_storage["n-mutation-places"] = genetic_config.n_mutation_places;
    genetic_storage["n-fast-trajectories"] = genetic_config.n_fast_trajectories;
    genetic_storage["n-evaluation-trajectories"] = genetic_config.n_evaluation_trajectories;
    genetic_storage["selection-size"] = genetic_config.selection_size;
    genetic_storage["recombination-proba"] = genetic_config.recombination_proba;
    return genetic_storage;
};


GeneticConfig JsonValueToGeneticConfig(const Json::Value& genetic_storage) {
    GeneticConfig genetic_config;
    genetic_config.n_genetic_iterations = genetic_storage["n-genetic-iterations"].asUInt();
    genetic_config.n_mutation_places = genetic_storage["n-mutation-places"].asUInt();
    genetic_config.n_fast_trajectories = genetic_storage["n-fast-trajectories"].asUInt();
    genetic_config.n_evaluation_trajectories
        = genetic_storage["n-evaluation-trajectories"].asUInt();
    genetic_config.selection_size = genetic_storage["selection-size"].asUInt();
    genetic_config.recombination_proba = genetic_storage["recombination-proba"].asDouble();
    return genetic_config;
}


GeneticPriceSearch::GeneticPriceSearch(
        const Setting& setting,
        const GeneticConfig& config)
        : optimal_revenue_(-std::numeric_limits<double>::max())
        , kSetting(setting)
        , kConfig(config) {
    std::shared_ptr<Sampler> sampler = std::make_shared<Sampler>(setting);
    trajectory_manager_ = std::make_shared<RandomTrajectoryManager>(
            setting, config.n_evaluation_trajectories, sampler, config.n_fast_trajectories);
    scorer_ = std::make_shared<SamplingScorer>(setting, trajectory_manager_);
    unsigned random_seed = 3;
    generator_.seed(random_seed);
}

StaticPriceList GeneticPriceSearch::PrepareStaticPrices(
        const std::vector<StaticPriceList>& initial_population) {
    trajectory_manager_->SetFastMode(true);
    std::vector<StaticPriceList> current_population = Select(initial_population);
    for (unsigned idx_iteration = 0;
                idx_iteration < kConfig.n_genetic_iterations; ++idx_iteration) {
        std::vector<StaticPriceList> next_generation
            = FormNextGeneration(current_population);
        current_population = Select(next_generation);
        trajectory_manager_->ResampleTrajectories();
        optimal_revenue_ = EvaluatePriceList(optimal_price_list_);
        BOOST_LOG_TRIVIAL(info) << "Completed Iteration " << idx_iteration + 1
            << " of " << kConfig.n_genetic_iterations << "."
            <<  " Optimal Revenue = " << optimal_revenue_ << "." << std::endl;
    }
    trajectory_manager_->SetFastMode(false);
    trajectory_manager_->ResampleTrajectories();
    Select(optimal_history_);
    return optimal_price_list_;
}

StaticPriceList GeneticPriceSearch::Mutate(const StaticPriceList& original_price_list) {
    std::vector<std::pair<unsigned, unsigned>> places_for_mutation;
    for (unsigned idx_period = 0; idx_period < kSetting.n_periods; ++idx_period) {
        for (unsigned idx_type = 0; idx_type < kSetting.n_order_types; ++idx_type) {
            std::pair<unsigned, unsigned> index_pair(idx_period, idx_type);
            places_for_mutation.push_back(index_pair);
        }
    }
    std::vector<std::pair<unsigned, unsigned>> sampled_places;
    std::default_random_engine generator;
    std::sample(places_for_mutation.begin(), places_for_mutation.end(),
            std::back_inserter(sampled_places),
            std::min(kConfig.n_mutation_places,
                static_cast<unsigned>(places_for_mutation.size())),
            generator);
    StaticPriceList mutated_price_list = original_price_list;
    for (const std::pair<unsigned, unsigned>& index_pair : sampled_places) {
        unsigned idx_period = index_pair.first;
        unsigned idx_type = index_pair.second;
        std::vector<double> possible_prices = kSetting.price_ranges[idx_period][idx_type];
        assert(possible_prices.size() > 0);
        std::uniform_int_distribution<unsigned> distribution(
                1, static_cast<unsigned>(possible_prices.size()));
        unsigned random_index = distribution(generator) % possible_prices.size();
        mutated_price_list.prices[idx_period][idx_type] = possible_prices[random_index];
    }
    return mutated_price_list;
}

StaticPriceList GeneticPriceSearch::Recombinate(
        const StaticPriceList& lhs, const StaticPriceList& rhs) {
    std::uniform_real_distribution<double> distribution(0., 1.);
    StaticPriceList recombinated_price_list;
    recombinated_price_list.prices.resize(kSetting.n_periods);
    for (unsigned idx_period = 0; idx_period < kSetting.n_periods; ++idx_period) {
        recombinated_price_list.prices[idx_period].resize(kSetting.n_order_types);
        for (unsigned idx_type = 0; idx_type < kSetting.n_order_types; ++idx_type) {
            if (distribution(generator_) < kConfig.recombination_proba) {
                recombinated_price_list.prices[idx_period][idx_type]
                    = lhs.prices[idx_period][idx_type];
            } else {
                recombinated_price_list.prices[idx_period][idx_type]
                    = rhs.prices[idx_period][idx_type];
            }
        }
    }
    return recombinated_price_list;
}

std::vector<StaticPriceList> GeneticPriceSearch::FormNextGeneration(
                const std::vector<StaticPriceList>& current_population) {
    std::vector<StaticPriceList> next_generation;
    for (unsigned idx = 0; idx < current_population.size(); ++idx) {
        next_generation.push_back(Mutate(current_population[idx]));
        next_generation.push_back(current_population[idx]);
        for (unsigned idy = idx + 1; idy < current_population.size(); ++idy) {
            next_generation.push_back(
                    Recombinate(current_population[idx], current_population[idy]));
        }
    }
    return next_generation;
}

std::vector<StaticPriceList> GeneticPriceSearch::Select(
        const std::vector<StaticPriceList>& price_list_candidates) {
    std::vector<std::pair<double, StaticPriceList>> scored_candidates;
    bool update_happened = false;
    for (const StaticPriceList& candidate_list : price_list_candidates) {
        double expected_revenue = EvaluatePriceList(candidate_list);
        if (expected_revenue > optimal_revenue_) {
            optimal_revenue_ = expected_revenue;
            optimal_price_list_ = candidate_list;
            update_happened = true;
        }
        scored_candidates.push_back(std::make_pair(expected_revenue, candidate_list));
    }
    if (update_happened && trajectory_manager_->GetFastMode()) {
        optimal_history_.push_back(optimal_price_list_);
    }
    std::sort(scored_candidates.begin(), scored_candidates.end(),
            [&](const std::pair<double, StaticPriceList>& lhs,
                const std::pair<double, StaticPriceList>& rhs) {
            return lhs.first > rhs.first;
    });
    std::vector<StaticPriceList> selected_price_lists;
    for (unsigned idx = 0; idx < kConfig.selection_size
            && idx < scored_candidates.size(); ++idx) {
        selected_price_lists.push_back(scored_candidates[idx].second);
    }
    return selected_price_lists;
}

double GeneticPriceSearch::EvaluatePriceList(const StaticPriceList& price_list) {
    std::shared_ptr<IOnlineScheduler> scheduler
        = std::make_shared <OnlineFIFOScheduler>(kSetting);
    std::shared_ptr<IPolicy> policy = std::make_shared<
        StaticPricePolicy>(price_list, kSetting, scheduler);
    return scorer_->GetScore(0, 0., policy).revenue_.average_;
}

} // namespace accurate
