#pragma once

#include <vector>
#include <random>
#include <json/json.h>

#include "../data/setting.h"
#include "../policy/static_price.h"
#include "../evaluate/scorer.h"


namespace accurate {

struct GeneticConfig {
    unsigned n_genetic_iterations = 100;
    unsigned n_mutation_places = 10;
    unsigned n_fast_trajectories = 50;
    unsigned n_evaluation_trajectories = 500;
    unsigned selection_size = 10;
    double recombination_proba = 0.5;
};


Json::Value GeneticConfigToJsonValue(const GeneticConfig& genetic_config);
GeneticConfig JsonValueToGeneticConfig(const Json::Value& genetic_storage);


class GeneticPriceSearch {
public:
    GeneticPriceSearch(const Setting& setting, const GeneticConfig& config);
    StaticPriceList PrepareStaticPrices(
            const std::vector<StaticPriceList>& initial_population);

private:
    StaticPriceList Mutate(const StaticPriceList& original);
    StaticPriceList Recombinate(const StaticPriceList& lhs, const StaticPriceList& rhs);
    std::vector<StaticPriceList> FormNextGeneration(
            const std::vector<StaticPriceList>& generation);
    std::vector<StaticPriceList> Select(const std::vector<StaticPriceList>& candidates);
    double EvaluatePriceList(const StaticPriceList& price_list);

private:
    double optimal_revenue_;
    StaticPriceList optimal_price_list_;
    std::vector<StaticPriceList> optimal_history_;

    std::shared_ptr<SamplingScorer> scorer_;
    std::shared_ptr<ITrajectoryManager> trajectory_manager_;
    std::default_random_engine generator_;

    const Setting kSetting;
    const GeneticConfig kConfig;
};

} // namespace accurate
