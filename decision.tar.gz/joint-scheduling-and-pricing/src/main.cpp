#include "research.h" // IWYU pragma: keep
#include "onboard.h"  // IWYU pragma: keep


int main([[maybe_unused]] int argc, [[maybe_unused]] char** argv) {
    #ifdef RESEARCH_MODE
    research::main(argc, argv);
    #endif
    #ifdef ONBOARD_MODE
    onboard::main(argc, argv);
    #endif
    return 0;
}
