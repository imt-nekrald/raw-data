#pragma once

namespace onboard {


int main(int argc, char** argv);


}