#include <string>
#include <vector>
#include <iostream>
#include <cassert>
#include <memory>
#include <boost/program_options.hpp>
#include <boost/log/trivial.hpp>

#include "onboard.h"
#include "api.h"
#include "data/setting.h"
#include "schedule/scheduling_state.h"
#include "search/genetic.h"
#include "policy/static_price.h"
#include "policy/rollout_price.h"
#include "schedule/scheduler_interface.h"
#include "schedule/fifo_scheduler.h"

namespace onboard {

struct OnboardingOptions {
    int random_seed;
    std::string configuration_json_path;
    std::string parameters_json_path;
    std::string request_json_path;
    std::string output_json_path;
    std::string log_save_dir;
};


namespace po = boost::program_options;


OnboardingOptions ParseOptions(int argc, char** argv) {
    OnboardingOptions options_parsed;
    po::options_description description("General Options");
    description.add_options()
        ("help,h", "Show help")
        // Accept multiple tokens after one occurrence and compose across multiple occurrences
        ("seed,s",
            po::value<int>(&options_parsed.random_seed)->default_value(18),
            "Random seed."
            )
        ("configuration-json-path,c",
            po::value<std::string>(
                &options_parsed.configuration_json_path)->default_value("configuration.json"),
            "Path to configuration json describing setting."
            )
        ("parameters-json-path,p",
            po::value<std::string>(
                &options_parsed.parameters_json_path)->default_value("parameters.json"),
            "Path to json describing algorithm parameters."
            )
        ("request-json-path,r",
            po::value<std::string>(
                &options_parsed.request_json_path)->default_value("request.json"),
            "Path to json describing request parameters."
            )
        ("output-json-path,o",
            po::value<std::string>(
                &options_parsed.output_json_path)->default_value("output.json"),
            "Path to output json describing response."
            )
        ("log-directory,l",
            po::value<std::string>(&options_parsed.log_save_dir)->default_value("logs/"),
            "Path to execution log directory."
            );
    try {
        po::variables_map argument_map;
        po::store(po::command_line_parser(argc, argv).options(description).run(), argument_map);
        if (argument_map.count("help")) {
            std::cout << description << "\n";
            std::exit(0);
        }
        po::notify(argument_map);
    } catch (const po::error& error) {
        std::cerr << "Error: " << error.what() << "\n\n" << description << "\n";
        throw error;
    }
    return options_parsed;
}


int main(int argc, char** argv) {
    OnboardingOptions options = ParseOptions(argc, argv);
    InitializeLogging(options.log_save_dir);

    Json::Value configuration_json(Json::objectValue);
    configuration_json = accurate::ParseJsonFromFile(options.configuration_json_path);
    accurate::Setting setting = accurate::JsonValueToSetting(configuration_json);

    BOOST_LOG_TRIVIAL(info) << "Setting is read from the json file.";

    Json::Value parameters_json(Json::objectValue);
    parameters_json = accurate::ParseJsonFromFile(options.parameters_json_path);
    Json::Value general_parameters_json = parameters_json["general-parameters"];
    unsigned evaluation_sample_count = general_parameters_json["evaluation-sample-count"].asUInt();
    unsigned rollout_sample_count = general_parameters_json["rollout-sample-count"].asUInt();
    unsigned estimator_time_limit = general_parameters_json["estimator-time-limit"].asUInt();
    unsigned nested_sample_count = general_parameters_json["nested-sample-count"].asUInt();

    BOOST_LOG_TRIVIAL(info) << "Parameters: "
        << " evaluation sample count = " << evaluation_sample_count
        << " rollout_sample_count = " << rollout_sample_count
        << " estimator_time_limit = " << estimator_time_limit;

    accurate::EvaluationBasis basis = accurate::PrepareEvaluationBasis(
        setting, estimator_time_limit, evaluation_sample_count, 
        rollout_sample_count, nested_sample_count);

    Json::Value request_json(Json::objectValue);
    request_json = accurate::ParseJsonFromFile(options.request_json_path);

    Json::Value output_storage;
    if (request_json["request-type"] == "lift") {
        // Goal 1: Search static table with genetic algorithm.
        // Goal 2: Estimate lifts.
        BOOST_LOG_TRIVIAL(info) << "Genetic search for static price table started.";
        Json::Value genetic_parameters_json = parameters_json["genetic-config"];
        accurate::GeneticConfig genetic_config = accurate::JsonValueToGeneticConfig(
            genetic_parameters_json);
        accurate::StaticPriceList static_price_list = accurate::PerformGeneticSearch(
            basis, genetic_config);
        output_storage["static-table"] = accurate::StaticPriceListToJsonValue(static_price_list);
        BOOST_LOG_TRIVIAL(info) << "Genetic search for static price table completed.";

        BOOST_LOG_TRIVIAL(info) << "Requesting static revenue estimation.";
        accurate::ConfidenceResult static_result;
        static_result = ComputeGeneticStaticRevenue(basis, static_price_list);
        Json::Value static_json;
        static_json["profit-lower-bound"] = static_result.revenue_.lower_bound_;
        static_json["profit_upper-bound"] = static_result.revenue_.upper_bound_;
        static_json["profit-average"] = static_result.revenue_.average_;
        output_storage["static-result"] = static_json;
        BOOST_LOG_TRIVIAL(info) << "Completed static revenue estimation.";
        BOOST_LOG_TRIVIAL(info) << "Static Average = " << static_result.revenue_.average_;

        BOOST_LOG_TRIVIAL(info) << "Requesting rollout revenue estimation.";
        accurate::ConfidenceResult rollout_result;
        rollout_result = ComputeGeneticRolloutRevenue(basis, static_price_list);
        Json::Value rollout_json;
        rollout_json["profit-lower-bound"] = rollout_result.revenue_.lower_bound_;
        rollout_json["profit_upper-bound"] = rollout_result.revenue_.upper_bound_;
        rollout_json["profit-average"] = rollout_result.revenue_.average_;
        output_storage["rollout-result"] = rollout_json;
        BOOST_LOG_TRIVIAL(info) << "Completed rollout revenue estimation.";
        BOOST_LOG_TRIVIAL(info) << "Rollout Average = " << rollout_result.revenue_.average_;
        BOOST_LOG_TRIVIAL(info) << "Estimated Lift = " << (
                rollout_result.revenue_.average_
                    / static_result.revenue_.average_ - 1.) * 100 << "%";
    } else if (request_json["request-type"] == "price"
            || request_json["request-type"] == "allocation") {
        Json::Value order_json = request_json["order-description"];
        accurate::OrderType order_type = accurate::JsonValueToOrderType(order_json);
        unsigned period = request_json["period-id"].asUInt();
        std::shared_ptr<accurate::IOnlineScheduler> scheduler
                = std::make_shared<accurate::OnlineFIFOScheduler>(basis.setting);
        accurate::SchedulingState state;
        if (request_json.isMember("production-state")) {
            Json::Value state_json = request_json["production-state"];
            state = accurate::JsonValueToSchedulingState(state_json);
        } else {
            state = basis.initial_state;
        }
        scheduler->SetState(state);
        if (request_json["request-type"] == "price") {
            std::string price_policy = request_json["price-policy"].asString();
            Json::Value static_json = request_json["static-table"];
            accurate::StaticPriceList static_table
                    = accurate::JsonValueToStaticPriceList(static_json);
            std::shared_ptr<accurate::IPolicy> static_policy = std::make_shared<
                    accurate::StaticPricePolicy>(static_table, basis.setting, scheduler);
            std::shared_ptr<accurate::IPolicy> rollout_policy = std::make_shared<
                    accurate::ExtendingRolloutPricePolicy>(
                            static_policy, basis.setting, basis.rollout_sample_count);
            std::shared_ptr<accurate::IPolicy> policy;
            if (price_policy == "static") {
                policy = static_policy;
            } else if (price_policy == "rollout") {
                policy = rollout_policy;
            }
            double suggested_price = policy->SuggestPrice(period, order_type);
            output_storage["price"] = suggested_price;
            output_storage["production-state"] = accurate::SchedulingStateToJsonValue(
                    policy->GetSchedulingState());
        } else if (request_json["request-type"] == "allocation") {
            double price = request_json["price"].asDouble();
            std::vector<accurate::SchedulingTask> order_tasks;
            double accumulated_time = request_json["accumualated-time"].asDouble();
            order_tasks = accurate::BuildTasksFromOrder(order_type, price, accumulated_time);
            scheduler->UpdateSchedule(period, order_tasks);
            output_storage["production-state"] = accurate::SchedulingStateToJsonValue(
                    scheduler->GetState());
        }
    }
    accurate::WriteJsonToFile(output_storage, options.output_json_path);
    return 0;
}


} // namespace onboard

