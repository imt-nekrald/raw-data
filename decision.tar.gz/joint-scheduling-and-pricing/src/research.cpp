#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <optional> // IWYU pragma: keep
#include <chrono> // IWYU pragma: keep
#include <filesystem> // IWYU pragma: keep
#include <json/json.h>
#include <boost/program_options.hpp>
#include <boost/log/trivial.hpp>

#include "data/setting.h"
#include "evaluate/confidence.h"  // IWYU pragma: keep
#include "search/genetic.h" // IWYU pragma: keep
#include "api.h" // IWYU pragma: keep
#include "research.h"


namespace research {
namespace po = boost::program_options;


OptionsParsed ParseOptions(int argc, char** argv) {
    const std::set<std::string> supported_calls = {
        "gurobi", "hexaly", "genetic", "minprice", "maxprice"
    };
    auto call_validator = [&](const std::vector<std::string>& input_calls) {
        for (const auto& request : input_calls) {
            if (supported_calls.find(request) == supported_calls.end()) {
                throw po::validation_error(
                    po::validation_error::invalid_option_value,
                    "Calls Validation Error",
                    request
                );
            }
        }
    };
    const std::set<std::string> supported_approaches = {
        "static", "rollout", "nested", "estimator"
    };
    auto approach_validator = [&](const std::vector<std::string>& input_approaches) {
        for (const auto& request : input_approaches) {
            if (supported_approaches.find(request) == supported_approaches.end()) {
                throw po::validation_error(
                    po::validation_error::invalid_option_value,
                    "Approaches Validation Error",
                    request
                );
            }
        }
    };
    accurate::InstanceTypeNameConverter converter;
    std::vector<std::string> possible_names = converter.RetrieveAllInstanceNames();
    const std::set<std::string> supported_instances(possible_names.begin(), possible_names.end());
    auto instance_validator = [&](const std::vector<std::string>& input_instances) {
        for (const auto& request : input_instances) {
            if (supported_instances.find(request) == supported_instances.end()) {
                throw po::validation_error(
                    po::validation_error::invalid_option_value,
                    "Instance Validation Error",
                    request
                );
            }
        }
    };
    OptionsParsed options_parsed;
    po::options_description description("General Options");
    std::string instance_explanation = std::string("List of instances. Supported: ")
        + converter.DescribeAllInstanceNames() + std::string(".");
    description.add_options()
        ("help,h", "Show help")
        // Accept multiple tokens after one occurrence and compose across multiple occurrences
        ("n-genetic-iterations,n",
            po::value<unsigned>(&options_parsed.n_genetic_iterations)->default_value(100),
            "Number of genetic iterations."
            )
        ("instances,i",
            po::value<std::vector<std::string>>(&options_parsed.instances_requested)
            ->multitoken()
            ->composing()
            ->notifier(instance_validator),
            instance_explanation.c_str()
            )
        ("seed,s",
            po::value<int>(&options_parsed.seed)->default_value(18),
            "Random seed."
            )
         ("approaches,a",
            po::value<std::vector<std::string>>(&options_parsed.approaches_requested)
            ->multitoken()
            ->composing()
            ->notifier(approach_validator),
            "List of approaches. Supported: static, rollout, nested, estimator."
             )
        ("report,r",
            po::value<std::string>(&options_parsed.report_path)->default_value("evaluation.json"),
            "Path to evaluation summary JSON file."
            )
        ("calls,c",
            po::value<std::vector<std::string>>(&options_parsed.calls_requested)
            ->multitoken()
            ->composing()
            ->notifier(call_validator),
            "List of calls. Supported: gurobi, hexaly, genetic, minprice, maxprice."
            );
    try {
        po::variables_map argument_map;
        po::store(po::command_line_parser(argc, argv).options(description).run(), argument_map);
        if (argument_map.count("help")) {
            std::cout << description << "\n";
            std::exit(0);
        }
        po::notify(argument_map);
    } catch (const po::error& error) {
        std::cerr << "Error: " << error.what() << "\n\n" << description << "\n";
        throw error;
    }
    return options_parsed;
}


unsigned RequestEstimatorTimeLimit(
        const accurate::InstanceType& instance_type) {
    const std::map <accurate::InstanceType, unsigned> kInstance2TimeLimit = {
        { accurate::InstanceType::MINIMAL_SINGLE_MACHINE, 100 },
        { accurate::InstanceType::SMALL_SINGLE_MACHINE, 300 },
        { accurate::InstanceType::MEDIUM_TWO_MACHINES, 400}
    };
    return kInstance2TimeLimit.at(instance_type);
}


accurate::GeneticConfig RequestGeneticConfig(
        const accurate::InstanceType& instance_type,
        unsigned n_genetic_iterations) {
    accurate::GeneticConfig genetic_config;
    genetic_config.n_genetic_iterations = n_genetic_iterations;
    const std::map <accurate::InstanceType, unsigned> kInstanceMutationPlaces = {
        { accurate::InstanceType::MINIMAL_SINGLE_MACHINE, 10 },
        { accurate::InstanceType::SMALL_SINGLE_MACHINE, 15 },
        { accurate::InstanceType::MEDIUM_TWO_MACHINES, 20}
    };
    const std::map <accurate::InstanceType, unsigned> kInstanceFastTrajectories = {
        { accurate::InstanceType::MINIMAL_SINGLE_MACHINE, 80 },
        { accurate::InstanceType::SMALL_SINGLE_MACHINE, 60 },
        { accurate::InstanceType::MEDIUM_TWO_MACHINES, 50}
    };
    const std::map <accurate::InstanceType, unsigned> kInstanceTrajectoriesFinalEvaluation = {
        { accurate::InstanceType::MINIMAL_SINGLE_MACHINE, 200 },
        { accurate::InstanceType::SMALL_SINGLE_MACHINE, 150 },
        { accurate::InstanceType::MEDIUM_TWO_MACHINES, 100}
    };
    const std::map <accurate::InstanceType, unsigned> kInstanceSelectionSize = {
        { accurate::InstanceType::MINIMAL_SINGLE_MACHINE, 20},
        { accurate::InstanceType::SMALL_SINGLE_MACHINE, 15},
        { accurate::InstanceType::MEDIUM_TWO_MACHINES, 10}
    };
    genetic_config.n_mutation_places = kInstanceMutationPlaces.at(instance_type);
    genetic_config.n_fast_trajectories = kInstanceFastTrajectories.at(instance_type);
    genetic_config.n_evaluation_trajectories = kInstanceTrajectoriesFinalEvaluation.at(instance_type);
    genetic_config.selection_size = kInstanceSelectionSize.at(instance_type);
    genetic_config.recombination_proba = 0.5;
    return genetic_config;
}

unsigned RequestRolloutTrajectoriesCount(const accurate::InstanceType& instance_type) {
    const std::map <accurate::InstanceType, unsigned> kInstance2RolloutTrajectories = {
        { accurate::InstanceType::MINIMAL_SINGLE_MACHINE, 80 },
        { accurate::InstanceType::SMALL_SINGLE_MACHINE, 70 },
        { accurate::InstanceType::MEDIUM_TWO_MACHINES, 60}
    };
    return kInstance2RolloutTrajectories.at(instance_type);
}


unsigned RequestNestedTrajectoriesCount(const accurate::InstanceType& instance_type) {
    const std::map <accurate::InstanceType, unsigned> kInstance2NestedTrajectories = {
        { accurate::InstanceType::MINIMAL_SINGLE_MACHINE, 20 },
        { accurate::InstanceType::SMALL_SINGLE_MACHINE, 15 },
        { accurate::InstanceType::MEDIUM_TWO_MACHINES, 10}
    };
    return kInstance2NestedTrajectories.at(instance_type);
}

unsigned RequestEvaluationSamplesCount(const accurate::InstanceType& instance_type) {
    const std::map <accurate::InstanceType, unsigned> kInstance2EvaluationSamples = {
        { accurate::InstanceType::MINIMAL_SINGLE_MACHINE, 100 },
        { accurate::InstanceType::SMALL_SINGLE_MACHINE, 50 },
        { accurate::InstanceType::MEDIUM_TWO_MACHINES, 50}
    };
    return kInstance2EvaluationSamples.at(instance_type);
}



#ifdef RESEARCH_MODE
int main(int argc, char** argv) {
    OptionsParsed options = ParseOptions(argc, argv);
    options.report_path = std::filesystem::absolute(options.report_path).string();
    std::set<std::string> call_set(
        options.calls_requested.begin(),
        options.calls_requested.end());
    std::set<std::string> approach_set(
        options.approaches_requested.begin(),
        options.approaches_requested.end());
    std::set<std::string> instance_set(
        options.instances_requested.begin(),
        options.instances_requested.end());

    unsigned random_seed = options.seed;
    std::srand(random_seed);

    Json::Value evaluation_summary(Json::objectValue);
    std::filesystem::path export_directory = std::filesystem::path(
                options.report_path).parent_path();
    if (!std::filesystem::exists(export_directory) && export_directory !=  "") {
        std::filesystem::create_directories(export_directory);
    }
    InitializeLogging("logs/");
    if (std::filesystem::exists(options.report_path)) {
        assert(std::filesystem::is_regular_file(options.report_path));
        evaluation_summary = accurate::ParseJsonFromFile(options.report_path);
    }
    assert(std::filesystem::exists(export_directory));
    evaluation_summary["seed"] = random_seed;

    for (const std::string& instance_request : instance_set) {
        if (!evaluation_summary.isMember(instance_request.c_str())) {
            evaluation_summary[instance_request.c_str()] = Json::Value(Json::objectValue);
        }
        auto instance_summary = evaluation_summary[instance_request.c_str()];

        accurate::InstanceTypeNameConverter converter;
        accurate::InstanceType instance_type = converter.NameToType(instance_request);

        const accurate::Setting& setting = BuildSettingInstance(instance_type);
        Json::Value setting_json = accurate::SettingToJsonValue(setting);
        accurate::WriteJsonToFile(
            setting_json, 
            (export_directory / (instance_request + "-configuration.json")).string());

        const unsigned estimator_time_limit = RequestEstimatorTimeLimit(instance_type);
        accurate::GeneticConfig genetic_config = RequestGeneticConfig(instance_type, options.n_genetic_iterations) ;
        const unsigned n_nested_trajectories = RequestNestedTrajectoriesCount(instance_type);
        const unsigned n_rollout_trajectories = RequestRolloutTrajectoriesCount(instance_type);
        const unsigned n_evaluation_samples = RequestEvaluationSamplesCount(instance_type);

        accurate::EvaluationBasis basis = accurate::PrepareEvaluationBasis(
            setting, estimator_time_limit, n_evaluation_samples, 
            n_rollout_trajectories, n_nested_trajectories);
        std::optional<accurate::StaticPriceList> genetic_price_list = std::nullopt;

        Json::Value genetic_json = accurate::GeneticConfigToJsonValue(genetic_config);
        Json::Value parameter_json = Json::Value(Json::objectValue);
        parameter_json["genetic"] = genetic_json;
        parameter_json["estimator-time-limit"] = estimator_time_limit;
        parameter_json["n-rollout-trajectories"] = n_rollout_trajectories;
        parameter_json["n-nested-trajectories"] = n_nested_trajectories;
        parameter_json["n-evaluation-samples"] = n_evaluation_samples;

        accurate::WriteJsonToFile(
            parameter_json, (export_directory / (instance_request + "-parameters.json")).string());
        for (const std::string& call_request : call_set) {
            if (!instance_summary.isMember(call_request.c_str())) {
                instance_summary[call_request.c_str()] = Json::Value(Json::objectValue);
            }
            auto& call_summary = instance_summary[call_request.c_str()];
            for (const std::string& approach_request : approach_set) {
                if (call_request == "genetic" && !genetic_price_list.has_value()
                            && approach_request != "estimator") {
                    auto start = std::chrono::steady_clock::now();
                    genetic_price_list = accurate::PerformGeneticSearch(basis, genetic_config);
                    auto end = std::chrono::steady_clock::now();
                    double genetic_duration = std::chrono::duration_cast<
                            std::chrono::milliseconds>(end - start).count() / 1000.;
                    call_summary["genetic-duration"] = genetic_duration;
                }
                if (!call_summary.isMember(approach_request.c_str())) {
                    call_summary[approach_request.c_str()] = Json::Value(Json::objectValue);
                }
                auto& approach_summary = call_summary[approach_request.c_str()];
                bool report_response = true;
                bool report_gap = false;
                auto start = std::chrono::steady_clock::now();
                accurate::ConfidenceResult return_value;
                if (call_request == "gurobi" && approach_request == "estimator") {
                    BOOST_LOG_TRIVIAL(info) << "Requested: Gurobi estimation\n";
                    return_value = ProcessGurobiEstimation(basis, false);
                    report_gap = true;
                } else if (call_request == "hexaly" && approach_request == "estimator") {
                    BOOST_LOG_TRIVIAL(info) << "Requested: Hexaly estimation\n";
                    return_value = ProcessHexalyEstimation(basis, false);
                } else if (call_request == "genetic" && approach_request == "static") {
                    BOOST_LOG_TRIVIAL(info) << "Requested: Genetic search. Static\n";
                    assert(genetic_price_list.has_value());
                    return_value = ComputeGeneticStaticRevenue(basis, genetic_price_list.value());
                } else if (call_request == "genetic" && approach_request == "rollout") {
                    BOOST_LOG_TRIVIAL(info) << "Requested: Genetic search. Rollout\n";
                    assert(genetic_price_list.has_value());
                    return_value = ComputeGeneticRolloutRevenue(basis, genetic_price_list.value());
                } else if (call_request == "genetic" && approach_request == "nested") {
                    BOOST_LOG_TRIVIAL(info) << "Requested: Genetic search. Nested\n";
                    assert(genetic_price_list.has_value());
                    return_value = ComputeGeneticNestedRevenue(basis, genetic_price_list.value());
                } else if (call_request == "minprice" && approach_request == "static") {
                    BOOST_LOG_TRIVIAL(info) << "Requested: Revenue at minimal prices. Static.\n";
                    return_value = ComputeRevenueAtMinimalPrice(basis);
                } else if (call_request == "maxprice" && approach_request == "static") {
                    BOOST_LOG_TRIVIAL(info) << "Requested: Revenue at maximal prices. Static.\n";
                    return_value = ComputeRevenueAtStaticMaximalPrice(basis);
                } else if (call_request == "maxprice" && approach_request == "rollout") {
                    BOOST_LOG_TRIVIAL(info) << "Requested: Revenue at maximal prices. Rollout.\n";
                    return_value = ComputeRevenueAtRolloutMaximalPrice(basis);
                } else {
                    report_response = false;
                }
                auto end = std::chrono::steady_clock::now();
                auto duration = std::chrono::duration_cast<
                        std::chrono::seconds>(end - start).count();
                if (report_response) {
                    approach_summary["duration"] = duration;
                    approach_summary["lower-revenue"] = return_value.revenue_.lower_bound_;
                    approach_summary["average-revenue"] = return_value.revenue_.average_;
                    approach_summary["upper-revenue"] = return_value.revenue_.upper_bound_;
                    approach_summary["observations-revenue"] = Json::Value(Json::arrayValue);
                    for (const double& observation : return_value.revenue_.observations_) {
                        approach_summary["observations-revenue"].append(observation);
                    }
                    if (report_gap) {
                        approach_summary["lower-gap"] = return_value.gap_.lower_bound_;
                        approach_summary["average-gap"] = return_value.gap_.average_;
                        approach_summary["upper-gap"] = return_value.gap_.upper_bound_;
                        approach_summary["observations-gap"] = Json::Value(Json::arrayValue);
                        for (const double& observation : return_value.gap_.observations_) {
                            approach_summary["observations-gap"].append(observation);
                        }
                        approach_summary["lower-mip-bound"] = return_value.bound_.lower_bound_;
                        approach_summary["upper-mip-bound"] = return_value.bound_.upper_bound_;
                        approach_summary["average-mip-bound"] = return_value.bound_.average_;
                        approach_summary["observations-mip-bound"] = Json::Value(Json::arrayValue);
                        for (const double& observation : return_value.bound_.observations_) {
                            approach_summary["observations-mip-bound"].append(observation);
                        }
                    }
                }
                call_summary[approach_request.c_str()] = approach_summary;
            }
            instance_summary[call_request.c_str()] = call_summary;
        }
        evaluation_summary[instance_request.c_str()] = instance_summary;
    }
    accurate::WriteJsonToFile(evaluation_summary, options.report_path);
    return 0;
}
#endif

} // namespace research

