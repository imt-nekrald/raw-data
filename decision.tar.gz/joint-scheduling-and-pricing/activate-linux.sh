#!/usr/bin/env bash

directory=`pwd`

export LD_LIBRARY_PATH="${LD_LIBRARY_PATH}:${directory}/lib/gurobi1300/linux64/lib:${directory}/lib/hexaly_14_0/bin"
export CMAKE_TOOLCHAIN_FILE="${directory}/lib/vcpkg/scripts/buildsystems/vcpkg.cmake"
export PATH="${PATH}:${directory}/lib/gurobi1300/linux64/bin:${directory}/lib/hexaly_14_0/bin"

export GRB_LICENSE_PATH="$HOME/gurobi.lic"
export HX_LICENSE_PATH="$HOME/hexaly.dat"

