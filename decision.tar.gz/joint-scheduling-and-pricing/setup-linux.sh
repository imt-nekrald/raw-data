#!/usr/bin/env bash

sudo apt-get install -y make cmake g++ build-essential
sudo apt-get install -y libboost-all-dev libjsoncpp-dev

rm -rf lib/
mkdir -p lib/hexaly_14_0
chmod +x external/optimizers/Hexaly_14_0_20251112_Linux64.run
external/optimizers/Hexaly_14_0_20251112_Linux64.run --nointeractive --noroot --target lib/hexaly_14_0
chmod -x external/optimizers/Hexaly_14_0_20251112_Linux64.run
tar -xzvf external/optimizers/gurobi13.0.0_linux64.tar.gz -C lib/

cd  lib
git clone https://github.com/Microsoft/vcpkg.git
cd vcpkg
./bootstrap-vcpkg.sh
./vcpkg integrate install
./vcpkg install jsoncpp
cd ..
